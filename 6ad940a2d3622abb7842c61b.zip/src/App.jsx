import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
// Add page imports here
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import ExploreScenarios from '@/pages/ExploreScenarios';
import ScenarioDetail from '@/pages/ScenarioDetail';
import ConsequenceLab from '@/pages/ConsequenceLab';
import CompareDecisions from '@/pages/CompareDecisions';
import MyInvestigations from '@/pages/MyInvestigations';
import InvestigationDetail from '@/pages/InvestigationDetail';
import InvestigationReport from '@/pages/InvestigationReport';
import About from '@/pages/About';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* Add your page Route elements here */}
        <Route path="/" element={<Home />} />
        <Route path="/explore" element={<ExploreScenarios />} />
        <Route path="/scenario/:scenarioId" element={<ScenarioDetail />} />
        <Route path="/lab" element={<ConsequenceLab />} />
        <Route path="/compare" element={<CompareDecisions />} />
        <Route path="/investigations" element={<MyInvestigations />} />
        <Route path="/investigations/:investigationId" element={<InvestigationDetail />} />
        <Route path="/investigations/:investigationId/report" element={<InvestigationReport />} />
        <Route path="/about" element={<About />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App