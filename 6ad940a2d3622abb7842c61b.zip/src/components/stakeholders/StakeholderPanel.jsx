import { CategoryChip, Chip } from '@/components/so/Chip';
import { DIRECTION_COLOR, DIRECTION_LABEL } from '@/lib/engine/types';

function List({ title, items, tone }) {
  if (!items?.length) return null;
  return (
    <div>
      <p className="font-mono text-[10px] uppercase tracking-[0.12em]" style={{ color: tone }}>
        {title}
      </p>
      <ul className="mt-2 space-y-1.5">
        {items.map((item, index) => (
          <li key={index} className="text-[12.5px] leading-relaxed text-slate-600">
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

/**
 * Stakeholder perspective. Selecting a stakeholder highlights the nodes that
 * may affect that group; the counts below are computed from the graph itself.
 */
export default function StakeholderPanel({ run, selectedId, onSelect, highlightOnMap, onToggleHighlight, className = '' }) {
  const stakeholders = run.scenario.stakeholders ?? [];
  const selected = stakeholders.find((stakeholder) => stakeholder.id === selectedId) ?? null;
  const affected = selected ? run.graph.nodes.filter((node) => selected.nodes.includes(node.id)) : [];

  return (
    <section className={className}>
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Stakeholder perspective</p>
      <p className="mt-2 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
        Groups are described by how the modelled effects could reach them, not by opinions attributed to them. Where a
        position is contested, that is stated as a conflict rather than resolved.
      </p>

      <div className="mt-4 flex flex-wrap gap-2">
        {stakeholders.map((stakeholder) => {
          const active = stakeholder.id === selectedId;
          return (
            <button
              key={stakeholder.id}
              type="button"
              onClick={() => onSelect(active ? null : stakeholder.id)}
              aria-pressed={active}
              className={`rounded-sm border px-3 py-1.5 text-[12px] transition-colors ${
                active ? 'border-teal bg-teal text-paper' : 'border-mist bg-white text-slate-600 hover:border-teal/50 hover:text-navy'
              }`}
            >
              {stakeholder.label}
            </button>
          );
        })}
      </div>

      {selected ? (
        <div className="mt-5 border border-mist bg-white p-5">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="font-heading text-[18px] text-navy">{selected.label}</h3>
              <p className="mt-1 max-w-2xl text-[12.5px] leading-relaxed text-slate-600">{selected.who}</p>
            </div>
            <button
              type="button"
              onClick={onToggleHighlight}
              aria-pressed={highlightOnMap}
              className={`rounded-sm border px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.08em] transition-colors ${
                highlightOnMap ? 'border-navy bg-navy text-paper' : 'border-mist bg-white text-slate-600 hover:border-navy/40 hover:text-navy'
              }`}
            >
              {highlightOnMap ? 'Highlighting on the map' : 'Highlight these nodes'}
            </button>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Chip>{affected.length} nodes affect this group</Chip>
            {['positive', 'negative', 'uncertain'].map((direction) => {
              const count = affected.filter((node) => node.direction === direction).length;
              if (!count) return null;
              return (
                <Chip key={direction} dot={DIRECTION_COLOR[direction]}>
                  {count} {DIRECTION_LABEL[direction].toLowerCase()}
                </Chip>
              );
            })}
          </div>

          <div className="mt-5 grid gap-x-8 gap-y-5 sm:grid-cols-2">
            <List title="Potential benefits" items={selected.benefits} tone="#4E8C87" />
            <List title="Potential costs" items={selected.costs} tone="#D8A04A" />
            <List title="Uncertainties" items={selected.uncertainties} tone="#5A6B78" />
            <List title="Conflicting interests" items={selected.conflicts} tone="#A8802F" />
          </div>

          <div className="mt-5 border-t border-mist pt-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-navy">Questions requiring further research</p>
            <ul className="mt-2 space-y-1.5">
              {(selected.questions ?? []).map((question, index) => (
                <li key={index} className="text-[12.5px] leading-relaxed text-slate-600">
                  {question}
                </li>
              ))}
            </ul>
          </div>

          <div className="mt-5 border-t border-mist pt-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-slate-500">Nodes that may reach this group</p>
            <ul className="mt-2 flex flex-wrap gap-2">
              {affected.map((node) => (
                <li key={node.id}>
                  <CategoryChip id={node.category} />
                  <span className="ml-2 text-[12px] text-slate-600">{node.title}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      ) : null}
    </section>
  );
}