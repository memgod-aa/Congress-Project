import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { format } from '@/lib/engine/format';

const FILLS = ['#17324D', '#4E8C87', '#D8A04A'];

/** One outcome, charted at its real modelled values across the selection. */
export default function OutcomeChart({ columns, row }) {
  if (!row) return null;
  const data = columns.map((column, index) => ({
    name: column.policyLabel,
    value: row.cells[index].missing ? 0 : Number(row.cells[index].value) || 0,
    missing: row.cells[index].missing,
    fill: FILLS[index % FILLS.length],
  }));

  return (
    <div>
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">{row.label}</p>
      <div className="mt-3 h-[240px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 8, right: 8, bottom: 8, left: 4 }}>
            <CartesianGrid stroke="#E6E8EB" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#5A6B78' }} tickLine={false} axisLine={{ stroke: '#E6E8EB' }} />
            <YAxis
              tick={{ fontSize: 11, fill: '#5A6B78' }}
              tickLine={false}
              axisLine={false}
              width={74}
              tickFormatter={(value) => format(value, row.format)}
            />
            <Tooltip
              formatter={(value, _name, entry) => [
                entry?.payload?.missing ? 'not modelled for this scenario' : format(value, row.format),
                row.label,
              ]}
              contentStyle={{ border: '1px solid #E6E8EB', borderRadius: 3, fontSize: 12, fontFamily: 'Inter, sans-serif' }}
              labelStyle={{ fontSize: 11, color: '#17324D' }}
            />
            <Bar dataKey="value" radius={[2, 2, 0, 0]}>
              {data.map((entry) => (
                <Cell key={entry.name} fill={entry.fill} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 text-[11.5px] text-slate-500">
        Values are the modelled outputs for each policy. A bar at zero means the outcome is not modelled for that
        scenario, not that it is zero.
      </p>
    </div>
  );
}