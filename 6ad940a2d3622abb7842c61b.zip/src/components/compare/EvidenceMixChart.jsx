import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { EVIDENCE_LEVELS } from '@/lib/engine/types';

const COLORS = {
  research: '#17324D',
  calculated: '#4E8C87',
  assumption: '#D8A04A',
  hypothesis: '#5A6B78',
};

/** Evidence mix per policy, counted from the graph nodes themselves. */
export default function EvidenceMixChart({ summary }) {
  const data = summary.map((entry) => ({
    name: entry.label,
    research: entry.research,
    calculated: entry.calculated,
    assumption: entry.assumption,
    hypothesis: entry.hypothesis,
  }));

  return (
    <div className="h-[240px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, bottom: 8, left: -18 }}>
          <CartesianGrid stroke="#E6E8EB" vertical={false} />
          <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#5A6B78' }} tickLine={false} axisLine={{ stroke: '#E6E8EB' }} />
          <YAxis tick={{ fontSize: 11, fill: '#5A6B78' }} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip
            contentStyle={{ border: '1px solid #E6E8EB', borderRadius: 3, fontSize: 12, fontFamily: 'Inter, sans-serif' }}
            labelStyle={{ fontSize: 11, color: '#17324D' }}
          />
          <Legend wrapperStyle={{ fontSize: 11, color: '#5A6B78' }} />
          {EVIDENCE_LEVELS.map((level) => (
            <Bar key={level.id} dataKey={level.id} stackId="evidence" fill={COLORS[level.id]} name={level.label} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}