/** Side-by-side text blocks, used for resources, unintended consequences and uncertainties. */
export default function ColumnLists({ title, note, groups, className = '' }) {
  return (
    <section className={className}>
      {title ? <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">{title}</p> : null}
      {note ? <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">{note}</p> : null}
      <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {groups.map((group) => (
          <div key={group.key} className="border border-mist bg-white p-4">
            <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{group.scenarioLabel}</p>
            <p className="mt-1 font-heading text-[16px] text-navy">{group.label}</p>
            <ul className="mt-3 space-y-2">
              {(group.items ?? []).map((item, index) => (
                <li key={index} className="text-[12.5px] leading-relaxed text-slate-600">
                  {item}
                </li>
              ))}
              {!(group.items ?? []).length ? (
                <li className="text-[12.5px] text-slate-400">None recorded for this policy.</li>
              ) : null}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}