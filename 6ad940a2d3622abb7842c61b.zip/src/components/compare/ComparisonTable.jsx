import { format } from '@/lib/engine/format';

function extremeIndex(values, preference) {
  if (!preference) return -1;
  const present = values.map((value, index) => ({ value, index })).filter((entry) => typeof entry.value === 'number');
  if (present.length < 2) return -1;
  const target = preference === 'lower' ? Math.min(...present.map((entry) => entry.value)) : Math.max(...present.map((entry) => entry.value));
  const found = present.find((entry) => entry.value === target);
  return found ? found.index : -1;
}

export default function ComparisonTable({ rows, columns, title, note, className = '' }) {
  if (!rows.length) return null;

  return (
    <section className={className}>
      {title ? <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">{title}</p> : null}
      {note ? <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">{note}</p> : null}

      <div className="mt-4 overflow-x-auto">
        <table className="w-full min-w-[640px] border-collapse text-left">
          <thead>
            <tr>
              <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Outcome</th>
              {columns.map((column) => (
                <th key={column.key} className="border-b border-navy/20 pb-2 pr-4 align-bottom">
                  <span className="block font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">
                    {column.scenarioLabel}
                  </span>
                  <span className="mt-0.5 block font-heading text-[15px] text-navy">{column.policyLabel}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => {
              const best = extremeIndex(
                row.cells.map((cell) => cell.value),
                row.preference,
              );
              return (
                <tr key={row.label} className="align-top">
                  <td className="border-b border-mist py-3 pr-4">
                    <span className="text-[12.5px] text-ink">{row.label}</span>
                    <span className="mt-1 block font-mono text-[9.5px] uppercase tracking-[0.08em] text-slate-400">
                      {row.preference ? `lower is generally preferred` : 'preference not defined'}
                    </span>
                  </td>
                  {row.cells.map((cell, index) => (
                    <td key={columns[index].key} className="border-b border-mist py-3 pr-4">
                      {cell.missing ? (
                        <span className="font-mono text-[12px] text-slate-400">not modelled for this scenario</span>
                      ) : (
                        <span className="flex flex-wrap items-baseline gap-2">
                          <span className={`tabular font-mono text-[13px] ${index === best ? 'text-navy' : 'text-slate-600'}`}>
                            {format(cell.value, cell.format)}
                          </span>
                          {index === best ? (
                            <span className="rounded-sm border border-navy/25 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-navy">
                              {row.preference === 'lower' ? 'lowest' : 'highest'}
                            </span>
                          ) : null}
                        </span>
                      )}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}