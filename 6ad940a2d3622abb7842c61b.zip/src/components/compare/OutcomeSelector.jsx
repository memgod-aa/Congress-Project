/**
 * The user chooses which outcomes they care about. No weighted total is
 * produced: selecting outcomes decides what is shown, never what wins.
 */
export default function OutcomeSelector({ options, selected, onChange, className = '' }) {
  const toggle = (label) => {
    onChange(selected.includes(label) ? selected.filter((entry) => entry !== label) : [...selected, label]);
  };

  return (
    <div className={className}>
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Outcomes you care about</p>
        <p className="max-w-xl text-[11.5px] leading-relaxed text-slate-500">
          There is no winner score. Selecting outcomes decides which rows are shown and charted; the markers only show
          which value is lowest or highest in that row, and rows point in different directions.
        </p>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {options.map((option) => {
          const active = selected.includes(option.label);
          return (
            <button
              key={option.label}
              type="button"
              onClick={() => toggle(option.label)}
              aria-pressed={active}
              className={`rounded-sm border px-3 py-1.5 text-[12px] transition-colors ${
                active ? 'border-teal bg-teal/10 text-navy' : 'border-mist bg-white text-slate-600 hover:border-teal/50 hover:text-navy'
              }`}
            >
              {option.label}
              <span className="ml-2 font-mono text-[9.5px] uppercase tracking-[0.08em] text-slate-400">{option.group}</span>
            </button>
          );
        })}
      </div>
      {!selected.length ? (
        <p role="status" className="mt-3 text-[12px] text-[#8a6420]">
          Select at least one outcome to chart the comparison.
        </p>
      ) : null}
    </div>
  );
}