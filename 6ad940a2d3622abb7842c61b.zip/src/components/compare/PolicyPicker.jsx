import { MAX_POLICIES, allPolicyOptions } from '@/lib/engine/compare';

/**
 * Policy selection for the comparison view. Options span all scenarios, so a
 * transport policy can be compared with a school policy on shared dimensions.
 */
export default function PolicyPicker({ selected, onChange, className = '' }) {
  const options = allPolicyOptions();
  const scenarios = [...new Set(options.map((option) => option.scenarioId))];
  const atLimit = selected.length >= MAX_POLICIES;

  const toggle = (key) => {
    if (selected.includes(key)) {
      onChange(selected.filter((entry) => entry !== key));
      return;
    }
    if (atLimit) return;
    onChange([...selected, key]);
  };

  return (
    <div className={className}>
      <div className="flex flex-wrap items-baseline justify-between gap-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
          Policies selected ({selected.length} of {MAX_POLICIES})
        </p>
        <p className="text-[11.5px] text-slate-500">Choose two or three. Up to three can be shown side by side.</p>
      </div>

      <div className="mt-3 space-y-4">
        {scenarios.map((scenarioId) => {
          const scenarioOptions = options.filter((option) => option.scenarioId === scenarioId);
          return (
            <div key={scenarioId}>
              <p className="font-mono text-[10px] uppercase tracking-[0.1em] text-navy">{scenarioOptions[0].scenarioLabel}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {scenarioOptions.map((option) => {
                  const active = selected.includes(option.key);
                  const disabled = !active && atLimit;
                  return (
                    <button
                      key={option.key}
                      type="button"
                      onClick={() => toggle(option.key)}
                      aria-pressed={active}
                      disabled={disabled}
                      title={option.summary}
                      className={`rounded-sm border px-3 py-1.5 text-[12px] transition-colors ${
                        active
                          ? 'border-navy bg-navy text-paper'
                          : disabled
                          ? 'cursor-not-allowed border-mist bg-white text-slate-300'
                          : 'border-mist bg-white text-slate-600 hover:border-navy/40 hover:text-navy'
                      }`}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {selected.length < 2 ? (
        <p role="status" className="mt-3 text-[12px] text-[#8a6420]">
          Select at least two policies to compare them.
        </p>
      ) : null}
    </div>
  );
}