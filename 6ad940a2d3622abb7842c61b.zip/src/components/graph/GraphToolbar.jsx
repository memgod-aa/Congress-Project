import { CATEGORIES, HIGHLIGHTS } from '@/lib/engine/types';

function ActionButton({ onClick, children, title }) {
  return (
    <button type="button" onClick={onClick} title={title} className="chip-sm">
      {children}
    </button>
  );
}

export default function GraphToolbar({
  graph,
  view,
  onChange,
  stakeholder,
  onClearStakeholder,
  onFocusDecision,
  onResetGraph,
  className = '',
}) {
  const levelOneIds = graph.nodes.filter((n) => n.level === 1).map((n) => n.id);
  const allIds = graph.nodes.filter((n) => (graph.childrenOf[n.id] ?? []).length > 0).map((n) => n.id);

  const toggleCategory = (id) => {
    const next = view.categories.includes(id) ? view.categories.filter((c) => c !== id) : [...view.categories, id];
    onChange({ ...view, categories: next });
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="flex flex-wrap items-center gap-1.5 border-b border-rule pb-3">
        <ActionButton onClick={() => onChange({ ...view, collapsed: [] })}>Expand all branches</ActionButton>
        <ActionButton onClick={() => onChange({ ...view, collapsed: allIds })}>Collapse all branches</ActionButton>
        <ActionButton onClick={() => onChange({ ...view, collapsed: levelOneIds })}>First order only</ActionButton>
        <ActionButton onClick={onFocusDecision}>Return to the decision</ActionButton>
        <ActionButton onClick={onResetGraph}>Reset the graph</ActionButton>
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <span className="sc sc-sm text-slate-500">Filter</span>
        <div className="flex flex-wrap items-center gap-1.5">
          {CATEGORIES.map((category) => {
            const active = view.categories.includes(category.id);
            const count = graph.nodes.filter((n) => n.category === category.id).length;
            return (
              <button
                key={category.id}
                type="button"
                onClick={() => toggleCategory(category.id)}
                aria-pressed={active}
                title={`${category.label} (${count} consequences)`}
                className={`flt inline-flex items-center gap-1.5 ${active ? 'on' : ''}`}
              >
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ background: active ? '#F3EEE4' : category.color }}
                />
                {category.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
        <span className="sc sc-sm text-slate-500">Highlight</span>
        <div className="flex flex-wrap items-center gap-1.5">
          {HIGHLIGHTS.map((option) => (
            <button
              key={option.id}
              type="button"
              onClick={() => onChange({ ...view, highlight: option.id })}
              aria-pressed={view.highlight === option.id}
              className={`flt ${view.highlight === option.id ? 'on' : ''}`}
            >
              {option.label}
            </button>
          ))}
        </div>

        {stakeholder ? (
          <button
            type="button"
            onClick={onClearStakeholder}
            className="chip-sm inline-flex items-center gap-2 border-oxblood/60 text-oxblood"
          >
            Highlighting: {stakeholder.label}
            <span className="text-slate-500">clear</span>
          </button>
        ) : null}
      </div>
    </div>
  );
}