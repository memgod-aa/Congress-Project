import { CATEGORIES, DIRECTIONS, NODE_TYPES, PALETTE } from '@/lib/engine/types';

/**
 * Legend for the map: how a consequence's category, type and direction of
 * effect are encoded. Node types use geometric glyphs rather than icons so the
 * drawing stays readable when the stack is zoomed out.
 */
export default function GraphLegend({ className = '' }) {
  return (
    <div className={`flex flex-wrap items-start gap-x-8 gap-y-4 border-t border-rule pt-4 ${className}`}>
      <div>
        <p className="sc sc-sm text-slate-500">Type of node</p>
        <ul className="mt-2 space-y-1.5">
          {NODE_TYPES.map((type) => (
            <li key={type.id} className="flex items-center gap-2 text-[11.5px] text-slate-600">
              <svg viewBox="-8 -8 16 16" className="h-3.5 w-3.5 shrink-0">
                {type.id === 'decision' ? (
                  <rect x={-4} y={-4} width={8} height={8} fill={PALETTE.navy} />
                ) : type.glyph === 'circle' ? (
                  <circle r={3.4} fill={PALETTE.slate} />
                ) : type.glyph === 'diamond' ? (
                  <path d="M0,-5 L5,0 L0,5 L-5,0 Z" fill="none" stroke={PALETTE.slate} strokeWidth={1.3} />
                ) : type.glyph === 'triangle' ? (
                  <path d="M0,-4.5 L4.5,3.5 L-4.5,3.5 Z" fill="none" stroke={PALETTE.ochre} strokeWidth={1.3} />
                ) : type.glyph === 'chevron' ? (
                  <path d="M-4,2.5 L0,-3.5 L4,2.5" fill="none" stroke={PALETTE.teal} strokeWidth={1.4} />
                ) : (
                  <path d="M-3.5,-4 L3.5,-4 L5,0 L3.5,4 L-3.5,4 L-5,0 Z" fill="none" stroke={PALETTE.teal} strokeWidth={1.2} />
                )}
              </svg>
              {type.label}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <p className="sc sc-sm text-slate-500">Direction of effect</p>
        <ul className="mt-2 space-y-1.5">
          {DIRECTIONS.map((direction) => (
            <li key={direction.id} className="flex items-center gap-2 text-[11.5px] text-slate-600">
              <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: direction.color }} />
              {direction.label}
            </li>
          ))}
        </ul>
      </div>

      <div className="max-w-xs">
        <p className="sc sc-sm text-slate-500">Category</p>
        <ul className="mt-2 flex flex-wrap gap-x-4 gap-y-1.5">
          {CATEGORIES.map((category) => (
            <li key={category.id} className="flex items-center gap-2 text-[11.5px] text-slate-600">
              <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: category.color }} />
              {category.label}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}