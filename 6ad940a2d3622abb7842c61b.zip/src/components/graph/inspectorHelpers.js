import { format } from '@/lib/engine/format';
import { getEvidence } from '@/lib/engine/types';

export { format };

/**
 * Honest statement of what an evidence label means for this node, so a reader
 * never has to guess whether a number came from arithmetic or from an
 * assumption.
 */
export function getEvidenceText(level) {
  const evidence = getEvidence(level);
  if (level === 'calculated') {
    return 'This value is arithmetic on the inputs you set, so it is exactly reproducible: the same inputs always give the same result. It is not an observation of the real world.';
  }
  if (level === 'assumption') {
    return 'No verified external source is attached to this claim. It is an illustrative assumption chosen by the scenario author so the system can be reasoned about, and it should be challenged before it is relied on.';
  }
  if (level === 'research') {
    return 'A verified source would be listed here. This prototype ships without attached citations rather than inventing them.';
  }
  if (level === 'hypothesis') {
    return 'This is a plausible mechanism that the model does not measure. It is listed as a question requiring further evidence, not as a result.';
  }
  return evidence.note;
}