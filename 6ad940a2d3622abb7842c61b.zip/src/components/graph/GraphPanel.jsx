import { useState } from 'react';
import { Crosshair } from 'lucide-react';
import GraphLegend from './GraphLegend';
import GraphToolbar from './GraphToolbar';
import IsoStack from './IsoStack';
import NodeInspector from './NodeInspector';

/**
 * The controlled consequence-map workspace: the stacked map, its controls and
 * legend, and the transparency panel. The page owns `view` and the selection so
 * the state can be saved into an investigation.
 */
export default function GraphPanel({
  run,
  view,
  onViewChange,
  selectedId,
  onSelect,
  stakeholder = null,
  onClearStakeholder,
  height = 540,
  compact = false,
  hideToolbar = false,
  hideInspector = false,
  className = '',
}) {
  const [focusToken, setFocusToken] = useState(0);
  const [focusNodeId, setFocusNodeId] = useState(null);

  const focusOn = (id) => {
    setFocusNodeId(id);
    setFocusToken((current) => current + 1);
  };

  const stakeholderIds = stakeholder?.nodes ?? [];
  const nodesForStakeholder = stakeholder
    ? run.graph.nodes.filter((node) => stakeholderIds.includes(node.id)).map((node) => node.id)
    : [];

  return (
    <div className={className}>
      <div className={`grid gap-5 ${compact || hideInspector ? '' : 'lg:grid-cols-[minmax(0,1fr)_330px]'}`}>
        <div>
          <IsoStack
            graph={run.graph}
            selectedId={selectedId}
            onSelect={onSelect}
            collapsed={view.collapsed}
            categories={view.categories}
            highlight={view.highlight}
            stakeholderIds={nodesForStakeholder}
            compact={compact}
            height={height}
            focusToken={focusToken}
            focusNodeId={focusNodeId}
            onToggleCollapse={(next) => onViewChange({ ...view, collapsed: next })}
          />

          {hideToolbar ? null : (
            <GraphToolbar
              className="mt-4"
              graph={run.graph}
              view={view}
              onChange={onViewChange}
              stakeholder={stakeholder}
              onClearStakeholder={onClearStakeholder}
              onFocusDecision={() => {
                onViewChange({ collapsed: [], categories: [], highlight: 'all' });
                onSelect(run.graph.rootId);
                focusOn(run.graph.rootId);
              }}
              onResetGraph={() => {
                onViewChange({ collapsed: [], categories: [], highlight: 'all' });
                onSelect(run.graph.rootId);
                focusOn(null);
              }}
            />
          )}

          <div className="mt-3 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => focusOn(selectedId ?? run.graph.rootId)}
              className="chip-sm inline-flex items-center gap-1.5"
            >
              <Crosshair className="h-3 w-3" />
              Centre on the selected node
            </button>
            <p className="text-[11.5px] leading-relaxed text-slate-600">
              Levels are derived from the parent chain, so a node can never claim an order of effect its own parents do
              not support.
            </p>
          </div>

          <GraphLegend className="mt-5" />
        </div>

        {hideInspector ? null : <NodeInspector run={run} node={run.graph.byId.get(selectedId) ?? null} onSelect={onSelect} />}
      </div>
    </div>
  );
}