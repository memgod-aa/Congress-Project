import { useEffect, useMemo, useRef, useState } from 'react';
import { Maximize2, Minus, Plus } from 'lucide-react';
import { computeHidden, layoutGraph } from '@/lib/engine/graph';
import {
  DIRECTION_COLOR,
  DIRECTION_LABEL,
  LEVELS,
  getCategory,
  getEvidence,
  getNodeType,
  levelMeta,
} from '@/lib/engine/types';

const COMPACT_OPTS = { colWidth: 248, rowHeight: 104, nodeWidth: 204, nodeHeight: 84 };
const REST = { x: 58, z: -38 };

/* Written out in full: Tailwind only keeps component CSS whose class name
   appears literally in the source, so these are never composed at runtime. */
const LAYER_CLASS = { 1: 'iso-ly iso-l1', 2: 'iso-ly iso-l2', 3: 'iso-ly iso-l3' };

const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

/**
 * Deterministic placement inside a layer: the order comes from the engine's
 * barycentre layout, so siblings that share an ancestor stay neighbours.
 */
function placeLevel(nodes) {
  const count = nodes.length || 1;
  const cols = count <= 1 ? 1 : count <= 4 ? 2 : count <= 9 ? 3 : 4;
  const rows = Math.ceil(count / cols);
  return nodes.map((node, index) => ({
    node,
    x: 8 + ((index % cols) + 0.5) * (84 / cols),
    y: 20 + (Math.floor(index / cols) + 0.5) * (70 / rows),
  }));
}

/**
 * The consequence map as an object in space: one sheet of paper per order of
 * effect, the decision floating nearest the viewer. Drag to orbit, scroll to
 * zoom, click a consequence to lift its card out of the stack.
 */
export default function IsoStack({
  graph,
  selectedId,
  onSelect,
  collapsed = [],
  categories = [],
  highlight = 'all',
  stakeholderIds = [],
  compact = false,
  height = 470,
  focusToken = 0,
  focusNodeId = null,
  onToggleCollapse,
  className = '',
}) {
  const layout = useMemo(() => layoutGraph(graph.nodes, compact ? COMPACT_OPTS : undefined), [graph, compact]);
  const hidden = useMemo(() => computeHidden(graph, collapsed), [graph, collapsed]);

  const [rot, setRot] = useState(REST);
  const [scale, setScale] = useState(1);
  const [dragging, setDragging] = useState(false);
  const [settled, setSettled] = useState(false);

  const stageRef = useRef(null);
  const dragRef = useRef(null);
  const movedRef = useRef(false);
  const tokenRef = useRef(focusToken);

  const levels = useMemo(() => {
    const byLevel = { 0: [], 1: [], 2: [], 3: [] };
    layout.nodes
      .filter((node) => !hidden.has(node.id))
      .forEach((node) => {
        const level = Math.min(Math.max(node.level ?? 0, 0), 3);
        byLevel[level].push(node);
      });
    return [3, 2, 1].map((level) => ({ level, placed: placeLevel(byLevel[level]), count: byLevel[level].length }));
  }, [layout, hidden]);

  const placements = useMemo(() => {
    const all = {};
    levels.forEach(({ placed }) => placed.forEach((entry) => { all[entry.node.id] = entry; }));
    return all;
  }, [levels]);

  const visibleCount = useMemo(() => levels.reduce((total, level) => total + level.count, 0) + (hidden.has(graph.rootId) ? 0 : 1), [levels, hidden, graph.rootId]);

  const selected = selectedId ? graph.byId.get(selectedId) ?? null : null;

  // The selected consequence's ancestry is lit back to the decision; every
  // branch off that path recedes.
  const litIds = useMemo(() => {
    const set = new Set();
    if (!selectedId) return set;
    const queue = [selectedId];
    while (queue.length) {
      const id = queue.shift();
      if (set.has(id)) continue;
      set.add(id);
      (graph.byId.get(id)?.parents ?? []).forEach((parent) => queue.push(parent));
    }
    return set;
  }, [graph, selectedId]);

  const isDim = (node) => {
    if (categories.length && !categories.includes(node.category)) return true;
    if (highlight === 'stakeholder') {
      if (node.type === 'decision') return false;
      return !stakeholderIds.includes(node.id);
    }
    if (highlight !== 'all' && node.type !== 'decision' && node.direction !== highlight) return true;
    return false;
  };

  useEffect(() => {
    const element = stageRef.current;
    if (!element) return undefined;
    const onWheel = (event) => {
      event.preventDefault();
      setScale((current) => clamp(current * (event.deltaY > 0 ? 0.94 : 1.06), 0.6, 1.6));
    };
    element.addEventListener('wheel', onWheel, { passive: false });
    return () => element.removeEventListener('wheel', onWheel);
  }, []);

  // "Centre on the selected node": turn the stack until that node faces you.
  useEffect(() => {
    if (focusToken === tokenRef.current) return;
    tokenRef.current = focusToken;
    const target = focusNodeId ? placements[focusNodeId] : null;
    if (!target) {
      setRot(REST);
      setScale(1);
      return;
    }
    setRot({ x: clamp(REST.x + (target.y - 55) * 0.14, 36, 72), z: clamp(REST.z - (target.x - 50) * 0.42, -78, -6) });
    setScale(1.15);
  }, [focusToken, focusNodeId, placements]);

  // Only recede when there is a path to tell: with the decision selected, the
  // whole tree stays at full strength.
  const pathActive = Boolean(selectedId && selectedId !== graph.rootId);

  const childCount = selected ? (graph.childrenOf[selected.id] ?? []).length : 0;

  return (
    <div className={`relative ${className}`}>
      <div
        ref={stageRef}
        className="iso-stage relative flex h-[300px] items-center justify-center overflow-hidden border border-rule bg-panel shadow-[18px_22px_30px_rgba(23,19,15,0.12)] [--iso-w:280px] [--iso-h:180px] [--iso-z:50px] [--iso-dw:112px] [--iso-dh:52px] sm:h-[400px] sm:[--iso-w:430px] sm:[--iso-h:274px] sm:[--iso-z:74px] sm:[--iso-dw:136px] sm:[--iso-dh:64px] lg:h-[var(--iso-stage)] lg:[--iso-w:520px] lg:[--iso-h:330px] lg:[--iso-z:90px] lg:[--iso-dw:150px] lg:[--iso-dh:70px]"
        style={{ '--iso-stage': `${height}px`, cursor: dragging ? 'grabbing' : 'grab', touchAction: 'none' }}
        onPointerDown={(event) => {
          if (event.button !== 0 && event.pointerType === 'mouse') return;
          dragRef.current = { x: event.clientX, y: event.clientY, rot };
          movedRef.current = false;
          setDragging(true);
          event.currentTarget.setPointerCapture?.(event.pointerId);
        }}
        onPointerMove={(event) => {
          const drag = dragRef.current;
          if (!drag) return;
          const dx = event.clientX - drag.x;
          const dy = event.clientY - drag.y;
          if (!movedRef.current && Math.abs(dx) + Math.abs(dy) < 4) return;
          movedRef.current = true;
          setRot({
            x: clamp(drag.rot.x - dy * 0.22, 36, 72),
            z: clamp(drag.rot.z + dx * 0.22, -78, -6),
          });
        }}
        onPointerUp={() => {
          dragRef.current = null;
          setDragging(false);
          window.setTimeout(() => {
            movedRef.current = false;
          }, 0);
        }}
        onPointerCancel={() => {
          dragRef.current = null;
          setDragging(false);
        }}
      >
        <div
          className={`iso-stack ${settled ? '' : 'iso-entering'}`}
          style={{
            '--iso-rx': `${rot.x}deg`,
            '--iso-rz': `${rot.z}deg`,
            '--iso-s': scale,
            width: 'var(--iso-w)',
            height: 'var(--iso-h)',
          }}
          onAnimationEnd={(event) => {
            if (event.target === event.currentTarget) setSettled(true);
          }}
        >
          {levels.map(({ level, placed, count }) =>
            count ? (
              <div key={level} className={LAYER_CLASS[level]}>
                <span className="sc text-oxblood">
                  {LEVELS[level].short} · {count}
                </span>
                {placed.map(({ node, x, y }) => {
                  const colour = DIRECTION_COLOR[node.direction] ?? DIRECTION_COLOR.uncertain;
                  const dimmed = isDim(node);
                  const lit = litIds.has(node.id);
                  const isOn = node.id === selectedId;
                  return (
                    <button
                      key={node.id}
                      type="button"
                      className={`iso-nd ${isOn ? 'is-on' : ''}`}
                      style={{
                        left: `${x}%`,
                        top: `${y}%`,
                        background: colour,
                        opacity: dimmed ? 0.15 : lit || !pathActive ? 1 : 0.62,
                        transform: `translate(-50%,-50%) scale(${isOn ? 1.5 : 1})`,
                      }}
                      title={`${node.title}${node.value ? ` — ${node.value}` : ''}`}
                      aria-label={`${node.title}. ${LEVELS[level].label}. ${getCategory(node.category).label}.`}
                      aria-pressed={isOn}
                      onClick={(event) => {
                        event.stopPropagation();
                        if (movedRef.current) return;
                        onSelect?.(node.id);
                      }}
                    />
                  );
                })}
              </div>
            ) : null,
          )}

          {hidden.has(graph.rootId) ? null : (
            <div className="iso-ly iso-l0">
              <span className="sc sc-sm" style={{ color: '#B8863B' }}>
                Decision
              </span>
            </div>
          )}
        </div>

        <div className="absolute bottom-3 right-3 flex items-center gap-1 border border-ink bg-panel/95 p-1 shadow-chip">
          <button
            type="button"
            onClick={() => setScale((current) => clamp(current * 0.86, 0.6, 1.6))}
            className="p-1.5 text-slate-600 transition-colors hover:text-ink"
            aria-label="Zoom out"
            title="Zoom out"
          >
            <Minus className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => setScale((current) => clamp(current * 1.16, 0.6, 1.6))}
            className="p-1.5 text-slate-600 transition-colors hover:text-ink"
            aria-label="Zoom in"
            title="Zoom in"
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => {
              setRot(REST);
              setScale(1);
            }}
            className="p-1.5 text-slate-600 transition-colors hover:text-ink"
            aria-label="Fit the whole map"
            title="Fit the whole map"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      <p className="iso-note mt-2">
        {visibleCount} consequences shown · drag to orbit · scroll or use the controls to zoom
      </p>

      {selected ? (
        <div className="sel-card mt-3 md:absolute md:right-0 md:top-1.5 md:z-[3] md:mt-0 md:w-[250px]">
          <p className="sc sc-sm text-oxblood">
            {levelMeta(selected.level).short} · {getCategory(selected.category).label}
          </p>
          <p className="mt-1.5 font-label text-[12px] text-slate-700">{getNodeType(selected.type).label}</p>
          <p className="mt-1 font-heading text-[19px] leading-[1.2]">{selected.title}</p>
          {selected.value ? <p className="mt-1 font-mono text-[12px] text-slate-700">{selected.value}</p> : null}
          <p className="mt-1 font-label text-[12px]" style={{ color: DIRECTION_COLOR[selected.direction] ?? DIRECTION_COLOR.uncertain }}>
            {DIRECTION_LABEL[selected.direction] ?? DIRECTION_LABEL.uncertain}
          </p>
          <p className="font-label text-[12px] text-slate-600">{getEvidence(selected.evidence).label}</p>

          {childCount ? (
            <button
              type="button"
              onClick={() =>
                onToggleCollapse?.(
                  collapsed.includes(selected.id)
                    ? collapsed.filter((id) => id !== selected.id)
                    : [...collapsed, selected.id],
                )
              }
              className="sc sc-sm mt-2.5 border-b border-brass text-oxblood transition-colors hover:text-ink"
            >
              {collapsed.includes(selected.id)
                ? `Expand this branch (${childCount})`
                : `Collapse this branch (${childCount})`}
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}