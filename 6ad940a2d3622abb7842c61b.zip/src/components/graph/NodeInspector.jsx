import { useEffect, useState } from 'react';
import { ArrowRight, Link2, Trash2 } from 'lucide-react';
import { CategoryChip, DirectionBadge, EvidenceBadge } from '@/components/so/Chip';
import { format, getEvidenceText } from '@/components/graph/inspectorHelpers';
import { getEvidence, getNodeType, levelMeta } from '@/lib/engine/types';
import { useNote } from '@/lib/storage/notes';

/**
 * Transparency panel for a single consequence: what it means, why it is here,
 * what influences it, the calculation behind it, the assumptions it rests on
 * and how strong the evidence is.
 */
export default function NodeInspector({ run, node, onSelect }) {
  const scenario = run.scenario;
  const [draftText, setDraftText] = useState('');
  const [draftLink, setDraftLink] = useState('');
  const [note, saveNote] = useNote(scenario.id, node?.id ?? 'none');

  useEffect(() => {
    setDraftText(note?.text ?? '');
    setDraftLink(note?.links?.[0]?.url ?? '');
  }, [note, node?.id]);

  if (!node) {
    return (
      <aside className="border border-dashed border-rule bg-panel/60 p-5">
        <p className="sc sc-sm text-slate-500">Transparency panel</p>
        <p className="mt-3 text-[13px] leading-relaxed text-slate-700">
          Select any consequence on the map to inspect what it means, why it is included, which variables influence it,
          the calculation behind it and the assumptions it rests on.
        </p>
      </aside>
    );
  }

  const level = levelMeta(node.level);
  const type = getNodeType(node.type);
  const evidence = getEvidence(node.evidence);
  const variables = (node.meta.variables ?? [])
    .map((key) => (scenario.variables ?? []).find((v) => v.key === key))
    .filter(Boolean);
  const assumptions = (node.meta.assumptions ?? [])
    .map((id) => (scenario.assumptions ?? []).find((a) => a.id === id))
    .filter(Boolean);
  const parents = node.parents.map((id) => run.graph.byId.get(id)).filter(Boolean);
  const children = (run.graph.childrenOf[node.id] ?? []).map((id) => run.graph.byId.get(id)).filter(Boolean);

  return (
    <aside className="border border-ink bg-panel p-5 shadow-paperInk lg:sticky lg:top-6">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="sc sc-sm text-slate-500">{level.short}</span>
        <CategoryChip id={node.category} />
        <span className="sc sc-sm text-slate-500">{type.label}</span>
      </div>

      <h3 className="mt-3 font-heading text-[19px] leading-snug">{node.title}</h3>

      {node.value ? <p className="mt-2 font-mono text-[11px] leading-relaxed text-slate-700">{node.value}</p> : null}

      <div className="mt-3 flex flex-wrap gap-1.5">
        <DirectionBadge direction={node.direction} />
        <EvidenceBadge level={node.evidence} />
      </div>

      <section className="mt-5 border-t border-rule pt-4">
        <h4 className="sc sc-sm text-slate-500">What this means</h4>
        <p className="mt-2 text-[13px] leading-relaxed text-ink">{node.meta.meaning}</p>
      </section>

      {node.meta.why ? (
        <section className="mt-4 border-t border-rule pt-4">
          <h4 className="sc sc-sm text-slate-500">Why it is included</h4>
          <p className="mt-2 text-[13px] leading-relaxed text-slate-700">{node.meta.why}</p>
        </section>
      ) : null}

      {variables.length ? (
        <section className="mt-4 border-t border-rule pt-4">
          <h4 className="sc sc-sm text-slate-500">Variables that influence it</h4>
          <ul className="mt-2 space-y-1.5">
            {variables.map((variable) => (
              <li key={variable.key} className="flex items-baseline justify-between gap-3">
                <span className="text-[12.5px] text-slate-700">{variable.label}</span>
                <span className="tabular font-mono text-[11px]">
                  {format(run.params[variable.key], variable.format ?? 'number')}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {node.meta.formula || node.meta.substitution ? (
        <section className="mt-4 border-t border-rule pt-4">
          <h4 className="sc sc-sm text-slate-500">Calculation</h4>
          {node.meta.formula ? (
            <p className="mt-2 font-mono text-[11px] leading-relaxed text-ink">{node.meta.formula}</p>
          ) : null}
          {node.meta.substitution ? (
            <p className="mt-2 break-words font-mono text-[11px] leading-relaxed text-slate-700">
              {node.meta.substitution}
            </p>
          ) : null}
        </section>
      ) : null}

      {assumptions.length ? (
        <section className="mt-4 border-t border-rule pt-4">
          <h4 className="sc sc-sm text-slate-500">Assumptions used</h4>
          <ul className="mt-2 space-y-3">
            {assumptions.map((assumption) => (
              <li key={assumption.id}>
                <p className="text-[12.5px] text-ink">{assumption.label}</p>
                <p className="mt-1 text-[12px] leading-relaxed text-slate-700">{assumption.text}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="mt-4 border-t border-rule pt-4">
        <h4 className="sc sc-sm text-slate-500">Evidence status</h4>
        <p className="mt-2 text-[12.5px] leading-relaxed text-slate-700">
          <span className="text-ink">{evidence.label}.</span> {evidence.note}
        </p>
        {(node.meta.sources ?? []).length ? (
          <ul className="mt-2 space-y-1">
            {node.meta.sources.map((source) => (
              <li key={source.url} className="text-[12px]">
                <a href={source.url} target="_blank" rel="noreferrer" className="text-oxblood underline decoration-oxblood/40">
                  {source.label ?? source.url}
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-[12px] leading-relaxed text-slate-700">{getEvidenceText(node.evidence)}</p>
        )}
      </section>

      {parents.length || children.length ? (
        <section className="mt-4 border-t border-rule pt-4">
          <h4 className="sc sc-sm text-slate-500">Connections</h4>
          <div className="mt-2 space-y-2">
            {parents.map((parent) => (
              <button
                key={parent.id}
                type="button"
                onClick={() => onSelect?.(parent.id)}
                className="flex w-full items-center gap-2 text-left text-[12px] text-slate-700 transition-colors hover:text-oxblood"
              >
                <ArrowRight className="h-3 w-3 shrink-0 rotate-180 text-slate-400" />
                caused by: {parent.title}
              </button>
            ))}
            {children.map((child) => (
              <button
                key={child.id}
                type="button"
                onClick={() => onSelect?.(child.id)}
                className="flex w-full items-center gap-2 text-left text-[12px] text-slate-700 transition-colors hover:text-oxblood"
              >
                <ArrowRight className="h-3 w-3 shrink-0 text-slate-400" />
                leads to: {child.title}
              </button>
            ))}
          </div>
        </section>
      ) : null}

      <section className="mt-4 border-t border-rule pt-4">
        <h4 className="sc sc-sm text-slate-500">Your notes and evidence</h4>
        <textarea
          value={draftText}
          onChange={(event) => setDraftText(event.target.value)}
          rows={3}
          placeholder="Add your own note about this consequence."
          className="field mt-2 w-full resize-y leading-relaxed"
        />
        <div className="mt-2 flex items-center gap-2">
          <Link2 className="h-3.5 w-3.5 shrink-0 text-slate-400" />
          <input
            value={draftLink}
            onChange={(event) => setDraftLink(event.target.value)}
            placeholder="Link to your own evidence (optional)"
            className="field w-full"
          />
        </div>
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() =>
              saveNote({
                text: draftText.trim(),
                links: draftLink.trim() ? [{ url: draftLink.trim(), label: draftLink.trim() }] : [],
              })
            }
            className="btn-ink is-quiet !py-1.5 !px-3 !text-[11px]"
          >
            Save note
          </button>
          {note ? (
            <button
              type="button"
              onClick={() => {
                setDraftText('');
                setDraftLink('');
                saveNote({ text: '', links: [] });
              }}
              className="chip-sm inline-flex items-center gap-1.5"
            >
              <Trash2 className="h-3 w-3" />
              Clear
            </button>
          ) : null}
          {note?.updatedAt ? <span className="iso-note">saved</span> : null}
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
          Notes are stored in this browser and included in exported reports.
        </p>
      </section>
    </aside>
  );
}