export default function PolicySelector({ scenario, policyId, onChange, className = '' }) {
  const selected = (scenario.alternatives ?? []).find((alternative) => alternative.id === policyId);

  return (
    <div className={className}>
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Alternative policy</p>
      <div className="mt-2 flex flex-wrap gap-2">
        {(scenario.alternatives ?? []).map((alternative) => {
          const active = alternative.id === policyId;
          return (
            <button
              key={alternative.id}
              type="button"
              onClick={() => onChange(alternative.id)}
              aria-pressed={active}
              className={`rounded-sm border px-3 py-2 text-left text-[12px] transition-colors ${
                active ? 'border-navy bg-navy text-paper' : 'border-mist bg-white text-slate-600 hover:border-navy/40 hover:text-navy'
              }`}
            >
              <span className="block font-medium">{alternative.short}</span>
              <span className={`mt-0.5 block font-mono text-[10px] uppercase tracking-[0.08em] ${active ? 'text-paper/60' : 'text-slate-400'}`}>
                {alternative.isBaseline ? 'reference case' : 'alternative'}
              </span>
            </button>
          );
        })}
      </div>
      {selected ? (
        <p className="mt-3 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
          <span className="text-navy">{selected.rootTitle}.</span> {selected.policySummary}
        </p>
      ) : null}
    </div>
  );
}