import MetricStat from '@/components/so/MetricStat';

export default function MetricsGrid({ run, groups, columns = 2 }) {
  const descriptors = (run.scenario.metrics ?? []).filter((metric) => !groups || groups.includes(metric.group));
  const uniqueGroups = [...new Set(descriptors.map((metric) => metric.group))];

  return (
    <div className="space-y-6">
      {uniqueGroups.map((group) => (
        <section key={group}>
          <h3 className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">{group}</h3>
          <div className={`mt-3 grid gap-x-8 gap-y-5 ${columns === 2 ? 'sm:grid-cols-2' : ''}`}>
            {descriptors
              .filter((metric) => metric.group === group)
              .map((metric) => (
                <MetricStat
                  key={metric.key}
                  descriptor={metric}
                  value={run.metrics[metric.key]}
                  baseline={run.baselineMetrics[metric.key]}
                  explain={run.explain?.[metric.key]}
                />
              ))}
          </div>
        </section>
      ))}
    </div>
  );
}