import { TONE_TEXT, format, fmtSignedCurrency, fmtSignedPercent } from '@/lib/engine/format';

/**
 * "What changed?" — built entirely from each metric's declared drivers, so the
 * attribution is computed rather than asserted.
 */
export default function ChangeExplainer({ run }) {
  if (!run.changes.length) {
    return (
      <div className="border border-mist bg-white p-5">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">What changed and why</p>
        <p className="mt-3 text-[13px] leading-relaxed text-slate-600">
          Every modelled output currently sits at its baseline value, so there is nothing to attribute. Move a variable
          or switch policy and this panel will show which inputs are responsible for the difference.
        </p>
      </div>
    );
  }

  return (
    <div className="border border-mist bg-white p-5">
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">What changed and why</p>
      <p className="mt-2 text-[12.5px] leading-relaxed text-slate-600">
        {run.changes.length} modelled {run.changes.length === 1 ? 'output differs' : 'outputs differ'} from the baseline.
        Each difference is attributed to the inputs that actually moved.
      </p>

      <ul className="mt-4 divide-y divide-mist">
        {run.changes.map((change) => {
          const deltaText = (() => {
            if (change.format === 'currency' || change.format === 'currency2') return fmtSignedCurrency(change.delta);
            if (String(change.format).startsWith('percent')) return fmtSignedPercent(change.delta);
            const sign = change.delta > 0 ? '+' : '\u2212';
            return `${sign}${format(Math.abs(change.delta), change.format)}`;
          })();

          return (
            <li key={change.key} className="py-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="text-[12.5px] text-navy">{change.label}</p>
                <p className={`tabular font-mono text-[11.5px] ${TONE_TEXT[change.tone] ?? TONE_TEXT.neutral}`}>
                  {format(change.baseline, change.format)} → {format(change.value, change.format)} ({deltaText})
                </p>
              </div>
              <ul className="mt-2 space-y-1">
                {change.drivers.map((driver) => (
                  <li key={driver.key} className="flex flex-wrap items-baseline gap-x-2 font-mono text-[11px] text-slate-600">
                    <span className="text-teal">{driver.label}</span>
                    <span>
                      {format(driver.from, driver.format)} → {format(driver.to, driver.format)}
                    </span>
                  </li>
                ))}
              </ul>
              {change.assumptions.length ? (
                <p className="mt-2 text-[11.5px] leading-relaxed text-slate-500">
                  Assumptions involved: {change.assumptions.map((assumption) => assumption.label).join(' · ')}
                </p>
              ) : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}