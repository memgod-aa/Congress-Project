export default function SummaryPanel({ run }) {
  const lines = run.scenario.summary(run.params, run.metrics, run.alternative);

  return (
    <div className="border-l-2 border-navy bg-white p-5">
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Simulation summary</p>
      <ul className="mt-3 space-y-3">
        {lines.map((line, index) => (
          <li key={index} className="text-[13px] leading-relaxed text-ink">
            {line}
          </li>
        ))}
      </ul>
      <p className="mt-4 border-t border-mist pt-3 text-[11.5px] leading-relaxed text-slate-500">
        These sentences are generated from the same numbers shown on the map, not written separately. Deterministic
        calculations, illustrative assumptions.
      </p>
    </div>
  );
}