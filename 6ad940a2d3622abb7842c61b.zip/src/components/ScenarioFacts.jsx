/**
 * Baseline conditions and the assumption register, shared by the scenario
 * overview and the Lab so the two can never drift apart.
 */
export default function ScenarioFacts({ scenario, compact = false, className = '' }) {
  return (
    <div className={className}>
      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Baseline conditions</p>
        <dl className={`mt-3 grid gap-x-8 gap-y-3 ${compact ? 'sm:grid-cols-2' : 'sm:grid-cols-2 lg:grid-cols-3'}`}>
          {scenario.baselineConditions.map((item) => (
            <div key={item.label} className="border-t border-mist pt-2.5">
              <dt className="text-[11.5px] text-slate-500">{item.label}</dt>
              <dd className="tabular mt-1 font-mono text-[13px] text-navy">{item.value}</dd>
              {item.note ? <p className="mt-1 text-[11px] leading-snug text-slate-500">{item.note}</p> : null}
            </div>
          ))}
        </dl>
      </section>

      <section className="mt-8">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
          Assumption register ({scenario.assumptions.length})
        </p>
        <p className="mt-2 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
          Every assumption the model uses, stated in full. Nothing here is a finding, and no citation has been invented
          to support one.
        </p>
        <ul className="mt-4 grid gap-x-8 gap-y-4 md:grid-cols-2">
          {scenario.assumptions.map((assumption) => (
            <li key={assumption.id} className="border-t border-mist pt-3">
              <p className="text-[12.5px] font-medium text-navy">{assumption.label}</p>
              <p className="mt-1.5 text-[12px] leading-relaxed text-slate-600">{assumption.text}</p>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}