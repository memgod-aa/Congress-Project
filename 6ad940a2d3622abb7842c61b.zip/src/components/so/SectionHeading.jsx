export default function SectionHeading({ eyebrow, title, note, id, level = 2, className = '' }) {
  const Tag = `h${level}`;
  return (
    <div className={className} id={id}>
      {eyebrow ? <p className="sc text-oxblood">{eyebrow}</p> : null}
      {title ? (
        <Tag className="mt-2 font-heading text-[28px] leading-[1.1] sm:text-[32px]">{title}</Tag>
      ) : null}
      {note ? (
        <p className="mt-2.5 max-w-[600px] font-heading text-[15px] italic leading-[1.55] text-slate-700">
          {note}
        </p>
      ) : null}
    </div>
  );
}