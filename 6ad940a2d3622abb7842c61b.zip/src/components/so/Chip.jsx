import { DIRECTION_COLOR, DIRECTION_LABEL, getCategory, getEvidence } from '@/lib/engine/types';

export function Chip({ children, dot, className = '', style }) {
  return (
    <span
      className={`sc sc-sm inline-flex items-center gap-1.5 border border-rule bg-panel px-2 py-[3px] font-semibold leading-none text-slate-600 ${className}`}
      style={style}
    >
      {dot ? <span className="h-1.5 w-1.5 rounded-full" style={{ background: dot }} /> : null}
      {children}
    </span>
  );
}

export function CategoryChip({ id, className = '' }) {
  const category = getCategory(id);
  return (
    <Chip dot={category.color} className={className}>
      {category.label}
    </Chip>
  );
}

export function DirectionBadge({ direction, className = '' }) {
  const color = DIRECTION_COLOR[direction] ?? DIRECTION_COLOR.uncertain;
  return (
    <Chip
      dot={color}
      className={className}
      style={{ color, borderColor: `${color}55`, background: `${color}0f` }}
    >
      {DIRECTION_LABEL[direction] ?? DIRECTION_LABEL.uncertain}
    </Chip>
  );
}

export function EvidenceBadge({ level, className = '' }) {
  const evidence = getEvidence(level);
  return (
    <Chip
      className={className}
      style={{ color: evidence.color, borderColor: `${evidence.color}55`, background: `${evidence.color}0f` }}
    >
      {evidence.label}
    </Chip>
  );
}