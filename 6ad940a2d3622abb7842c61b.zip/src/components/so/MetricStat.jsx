import { TONE_TEXT, format, fmtSignedCurrency, fmtSignedPercent } from '@/lib/engine/format';

/**
 * One modelled output, shown against the baseline it is measured from.
 * Delta colour is decided by the metric's declared tone: 'neutral' means the
 * model deliberately does not judge the direction as good or bad.
 */
export default function MetricStat({ descriptor, value, baseline, explain, className = '' }) {
  const delta = Number.isFinite(value) && Number.isFinite(baseline) ? value - baseline : null;
  const tone = descriptor?.tone ?? 'neutral';
  const changed = delta !== null && Math.abs(delta) > 1e-9;

  const deltaText = (() => {
    if (delta === null) return null;
    if (!changed) return 'no change from baseline';
    if (descriptor.format === 'percent0' || descriptor.format === 'percent') return `${fmtSignedPercent(delta)} from baseline`;
    if (descriptor.format === 'currency' || descriptor.format === 'currency2') return `${fmtSignedCurrency(delta)} from baseline`;
    const sign = delta > 0 ? '+' : '\u2212';
    return `${sign}${format(Math.abs(delta), descriptor.format ?? 'number')} from baseline`;
  })();

  return (
    <div className={`border-t border-ink/70 pt-3 ${className}`}>
      <p className="sc sc-sm text-slate-500">{descriptor.label}</p>
      <p className="tabular mt-1.5 font-heading text-[22px] leading-none">{format(value, descriptor.format ?? 'number')}</p>
      <p className={`tabular mt-1.5 font-label text-[11.5px] ${changed ? TONE_TEXT[tone] : 'text-slate-500'}`}>
        {changed ? deltaText : `as at baseline (${format(baseline, descriptor.format ?? 'number')})`}
      </p>
      {explain ? <p className="mt-2 font-mono text-[10.5px] leading-relaxed text-slate-500">{explain}</p> : null}
    </div>
  );
}