import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, X } from 'lucide-react';
import { DEMO_TOTAL, demoStep, nextStepUrl, previousStepUrl } from '@/lib/demo';
import { ensureDemoInvestigation } from '@/lib/storage/investigations';

/**
 * Guided demonstration bar. It appears only while a `demo` step is present in
 * the URL, and each step drives the real application rather than a mock.
 */
export default function DemoBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const stepParam = new URLSearchParams(location.search).get('demo');

  // The demonstration is built around a complete worked investigation, so it
  // exists from the first step onward rather than appearing at the end.
  useEffect(() => {
    if (stepParam) ensureDemoInvestigation();
  }, [stepParam]);

  if (!stepParam) return null;

  const step = demoStep(stepParam);
  const next = nextStepUrl(step.id);
  const previous = previousStepUrl(step.id);

  return (
    <div className="no-print fixed inset-x-0 bottom-0 z-40 border-t border-brass/60 bg-ink px-4 py-3 text-sheet">
      <div className="mx-auto flex max-w-[1180px] flex-wrap items-center gap-x-5 gap-y-3">
        <span className="sc sc-sm text-brass">
          Demonstration {step.id} / {DEMO_TOTAL}
        </span>
        <div className="min-w-[220px] flex-1">
          <p className="font-heading text-[15px] leading-tight">{step.title}</p>
          <p className="mt-0.5 text-[12px] leading-snug text-sheet/65">{step.instruction}</p>
        </div>
        <div className="flex items-center gap-2">
          {previous ? (
            <button
              type="button"
              onClick={() => navigate(previous)}
              className="inline-flex items-center gap-1.5 border border-sheet/30 px-3 py-1.5 font-label text-[11px] tracking-[0.06em] text-sheet/80 transition-colors hover:border-brass hover:text-brass"
            >
              <ArrowLeft className="h-3 w-3" />
              Back
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => navigate(next ?? '/investigations')}
            className="btn-ox sc inline-flex items-center gap-1.5"
          >
            {next ? 'Next' : 'Finish'}
            <ArrowRight className="h-3 w-3" />
          </button>
          <button
            type="button"
            onClick={() => navigate('/')}
            className="inline-flex items-center gap-1.5 px-2 py-1.5 font-label text-[11px] tracking-[0.06em] text-sheet/50 transition-colors hover:text-brass"
          >
            <X className="h-3 w-3" />
            Exit
          </button>
        </div>
      </div>
    </div>
  );
}