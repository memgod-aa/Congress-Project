import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import DemoBar from '@/components/DemoBar';
import { launchDemo } from '@/lib/demo';

const NAV_ITEMS = [
  { to: '/', label: 'Home', end: true },
  { to: '/explore', label: 'Explore Scenarios' },
  { to: '/lab?scenario=transit', label: 'Consequence Lab' },
  { to: '/compare', label: 'Compare Decisions' },
  { to: '/investigations', label: 'My Investigations' },
  { to: '/about', label: 'About' },
];

function BrandMark({ className = '' }) {
  return (
    <svg viewBox="0 0 30 30" className={className} aria-hidden="true">
      <circle cx="15" cy="5" r="3.5" fill="#7A2130" />
      <circle cx="6" cy="22" r="3" fill="#17130F" />
      <circle cx="24" cy="22" r="3" fill="#B8863B" />
      <path d="M15 8.5L6 19M15 8.5L24 19" stroke="#17130F" strokeWidth="1.5" fill="none" />
    </svg>
  );
}

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const demoActive = Boolean(new URLSearchParams(location.search).get('demo'));

  return (
    <div className="min-h-screen bg-sheet text-ink">
      <div className="mx-auto w-full max-w-[1180px] px-5 py-8 sm:px-8 sm:py-10">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-2 border-b border-ink pb-3.5">
          <Link to="/" className="flex items-center gap-3">
            <BrandMark className="h-[30px] w-[30px]" />
            <span className="font-heading text-[20px] leading-none">SecondOrder</span>
          </Link>
          <p className="ml-auto font-heading text-[13px] italic text-slate-600">
            Every decision creates another.
          </p>
        </div>

        <nav className="sc flex flex-wrap items-center gap-x-[18px] gap-y-1.5 border-b border-rule py-3">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `border-b border-transparent pb-[3px] transition-colors hover:text-oxblood ${
                  isActive ? 'border-oxblood text-oxblood' : 'text-ink'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
          <button type="button" onClick={() => navigate(launchDemo())} className="btn-ox sc ml-auto">
            Launch Demo
          </button>
        </nav>

        <main className={demoActive ? 'pb-40' : ''}>
          <Outlet />
        </main>

        <footer className="no-print mt-16 border-t border-ink pt-4">
          <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-2">
            <p className="max-w-2xl text-[12px] leading-[1.6] text-slate-600">
              SecondOrder — an interactive decision-simulation prototype. Fictional settings, illustrative values.
              Nothing here is a finding: every number is either calculated from your inputs or labelled as an
              assumption, and no citation is invented.
            </p>
            <Link to="/about" className="sc-sm sc text-oxblood hover:text-ink">
              How the models work
            </Link>
          </div>
        </footer>
      </div>

      <DemoBar />
    </div>
  );
}