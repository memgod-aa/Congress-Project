import { countByLevel } from '@/lib/engine/graph';
import { LEVELS } from '@/lib/engine/types';

const EXPLANATIONS = {
  1: 'Direct consequences: what the decision changes immediately, with arithmetic the model can actually perform.',
  2: 'Second-order effects: consequences caused by the first effects. This is where crowding, funding and staffing appear.',
  3: 'Third-order effects: further consequences that only emerge once the system has adjusted. Most of these are hypotheses, not results.',
};

const ACCENTS = { 1: '#7A2130', 2: '#17130F', 3: '#B8863B' };

/** One hairline rule with a tick per consequence at that order of effect. */
function CountRule({ count, accent }) {
  const width = 200;
  const height = 14;
  const dots = Math.min(count, 24);
  return (
    <svg className="mt-2.5 block" width={width} height={height} role="img" aria-label={`${count} consequences`}>
      <path d={`M0 7H${width}`} stroke="#17130F" strokeWidth="0.8" />
      {Array.from({ length: dots }).map((_, index) => (
        <circle
          key={index}
          cx={((index + 1) / (dots + 1)) * width}
          cy="7"
          r="4"
          fill={accent}
        />
      ))}
    </svg>
  );
}

export default function LevelsSection({ graph }) {
  const counts = countByLevel(graph.nodes);

  return (
    <section className="pt-10">
      <p className="sc text-oxblood">Reading the map</p>
      <h2 className="mt-2 font-heading text-[30px] leading-[1.1] sm:text-[34px]">One decision. Multiple futures.</h2>
      <p className="mt-2.5 max-w-[560px] font-heading text-[15px] italic leading-[1.55] text-slate-700">
        Consequences are not a list, they are a chain. Each order of effect is caused by the one before it, and the map
        shows the chain explicitly so you can see where your confidence should stop.
      </p>

      <div className="mt-6 flex flex-col gap-[18px]">
        {LEVELS.filter((level) => level.level > 0).map((level, index) => (
          <article
            key={level.level}
            className={`grid grid-cols-[52px_1fr] border border-rule bg-panel shadow-paper sm:grid-cols-[64px_1fr] ${
              index === 1 ? 'md:ml-6' : index === 2 ? 'md:ml-12' : ''
            }`}
          >
            <div
              className="flex items-center justify-center font-heading text-[30px] text-sheet sm:text-[34px]"
              style={{ background: ACCENTS[level.level] }}
            >
              {level.level}
            </div>
            <div className="px-4 py-4 sm:px-5">
              <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
                <h4 className="font-heading text-[21px]">{level.label}</h4>
                <span className="font-mono text-[12px] text-slate-600">
                  {counts[level.level] ?? 0} in this scenario
                </span>
              </div>
              <p className="mt-2 text-[14px] leading-[1.55] text-slate-800">{EXPLANATIONS[level.level]}</p>
              <CountRule count={counts[level.level] ?? 0} accent={ACCENTS[level.level]} />
            </div>
          </article>
        ))}
      </div>

      <p className="mt-7 max-w-[600px] border-l-[3px] border-brass pl-4 font-heading text-[16px] italic leading-[1.6] text-slate-800">
        The decision itself is the root node. Every consequence descends from it, either directly or through another
        consequence — the map never shows an effect that is not connected to the choice that caused it.
      </p>
    </section>
  );
}