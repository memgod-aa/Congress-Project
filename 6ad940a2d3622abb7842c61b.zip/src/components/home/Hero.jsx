import { Link } from 'react-router-dom';

export default function Hero() {
  return (
    <section className="grid gap-8 border-b-[3px] border-double border-ink pb-[30px] pt-[34px] md:grid-cols-[1.25fr_1fr]">
      <div>
        <p className="sc text-oxblood">Interactive decision simulation</p>
        <h1 className="mt-3.5 font-heading text-[38px] leading-[1.02] sm:text-[46px] lg:text-[54px]">
          The first consequence is rarely the last.
        </h1>
      </div>

      <div className="md:pt-[26px]">
        <p className="font-body text-[16px] leading-[1.55] text-slate-800">
          Every decision changes a system. Explore the effects you expect, uncover the ones you don't, and see how
          different choices reshape the outcome.
        </p>

        <div className="mt-5 flex flex-col gap-2.5">
          <Link to="/explore" className="btn-ink">
            Explore a Scenario
            <span aria-hidden="true">→</span>
          </Link>
          <Link to="/lab?scenario=transit" className="btn-ink is-quiet">
            Enter the Consequence Lab
            <span aria-hidden="true">⚗</span>
          </Link>
        </div>

        <p className="iso-note sc-sm sc mt-4">No account needed · illustrative models · every assumption labelled</p>
      </div>
    </section>
  );
}