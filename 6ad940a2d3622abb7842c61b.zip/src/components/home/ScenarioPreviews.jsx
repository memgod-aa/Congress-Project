import { Link } from 'react-router-dom';
import { listScenarios } from '@/lib/engine/registry';

export default function ScenarioPreviews() {
  const scenarios = listScenarios();

  return (
    <section className="pt-10">
      <p className="sc text-oxblood">Start somewhere concrete</p>
      <h2 className="mt-2 font-heading text-[30px] leading-[1.1] sm:text-[34px]">Three decisions, modelled end to end</h2>
      <p className="mt-2.5 max-w-[560px] font-heading text-[15px] italic leading-[1.55] text-slate-700">
        Each scenario opens as a full simulation: the decision, its baseline conditions, the consequence map, adjustable
        variables, alternative policies and a stakeholder analysis.
      </p>

      <div className="mt-6 border-t border-ink">
        {scenarios.map((scenario, index) => (
          <article
            key={scenario.id}
            className="grid grid-cols-[52px_1fr] gap-x-3.5 border-b border-rule py-[22px] sm:grid-cols-[70px_1fr]"
          >
            <div className="font-heading text-[40px] italic leading-none text-oxblood sm:text-[52px]">{index + 1}</div>
            <div>
              <p className="sc text-oxblood">{scenario.shortTitle}</p>
              <h3 className="mt-1.5 font-heading text-[22px] leading-[1.15] sm:text-[25px]">{scenario.homeTitle}</h3>
              <p className="mt-2 text-[14px] leading-[1.55] text-slate-700">{scenario.setting}</p>
              <div className="mt-3.5 flex flex-wrap items-center gap-x-[18px] gap-y-2">
                <Link to={`/scenario/${scenario.id}`} className="lnk">
                  Open simulation
                  <span aria-hidden="true">→</span>
                </Link>
                <Link to={`/lab?scenario=${scenario.id}`} className="lnk is-text">
                  Open in the Lab
                </Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}