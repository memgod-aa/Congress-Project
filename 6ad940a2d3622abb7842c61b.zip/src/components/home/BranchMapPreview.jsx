import { useMemo, useState } from 'react';
import GraphPanel from '@/components/graph/GraphPanel';
import { effectiveParams, runScenario } from '@/lib/engine/registry';

/**
 * The live example on the home page: the real engine, the real graph, the real
 * transparency panel — the whole effect tree lifted into four paper layers,
 * opened at first-order effects and expandable in place.
 */
export default function BranchMapPreview() {
  const run = useMemo(() => runScenario('transit', effectiveParams('transit', 'free'), 'free'), []);
  const levelOneIds = useMemo(() => run.graph.nodes.filter((n) => n.level === 1).map((n) => n.id), [run.graph]);
  // Opens with every order of effect stacked; the control collapses it back to
  // first-order effects for a first pass over the decision.
  const [view, setView] = useState({ collapsed: [], categories: [], highlight: 'all' });
  const [selectedId, setSelectedId] = useState('fare-revenue');

  const expanded = view.collapsed.length === 0;

  return (
    <div>
      <div className="mt-10 flex flex-col gap-4 border-b border-rule pb-3.5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="sc text-oxblood">Live consequence map</p>
          <h3 className="mt-1.5 font-heading text-[22px] leading-[1.15] sm:text-[24px]">{run.scenario.decision}</h3>
          <small className="mt-1 block max-w-[360px] font-body text-[12.5px] leading-[1.4] text-slate-600">
            {run.scenario.setting} Values are illustrative.
          </small>
        </div>
        <button
          type="button"
          onClick={() => setView({ ...view, collapsed: expanded ? levelOneIds : [] })}
          className="chip"
        >
          {expanded ? 'Collapse to first-order effects' : 'Show second- and third-order effects'}
        </button>
      </div>

      <GraphPanel
        className="mt-5"
        run={run}
        view={view}
        onViewChange={setView}
        selectedId={selectedId}
        onSelect={setSelectedId}
        height={470}
      />
    </div>
  );
}