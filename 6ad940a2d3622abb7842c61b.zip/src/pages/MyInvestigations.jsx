import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bookmark, Copy, Pencil, Play, Printer, Trash2 } from 'lucide-react';
import SectionHeading from '@/components/so/SectionHeading';
import { getScenario } from '@/lib/engine/registry';
import {
  deleteInvestigation,
  duplicateInvestigation,
  ensureDemoInvestigation,
  renameInvestigation,
  useInvestigations,
} from '@/lib/storage/investigations';

function formatDate(value) {
  if (!value) return '—';
  return new Date(value).toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
}

export default function MyInvestigations() {
  const { investigations, refresh } = useInvestigations();
  const navigate = useNavigate();
  const [editingId, setEditingId] = useState(null);
  const [draft, setDraft] = useState('');
  const [confirmId, setConfirmId] = useState(null);

  const loadDemo = () => {
    const record = ensureDemoInvestigation();
    refresh();
    navigate(`/investigations/${record.id}`);
  };

  return (
    <div className="space-y-10">
      <header className="flex flex-wrap items-end justify-between gap-5">
        <SectionHeading
          eyebrow="My Investigations"
          title="Saved investigations"
          note="Each saved investigation keeps the scenario, the policy, every parameter, the state of the consequence map and your notes. They are stored in this browser — no account is needed, and nothing is uploaded anywhere."
          level={1}
        />
        <button
          type="button"
          onClick={loadDemo}
          className="inline-flex items-center gap-2 rounded-sm border border-ochre bg-ochre/10 px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-[#8a6420] transition-colors hover:bg-ochre/20"
        >
          <Play className="h-3.5 w-3.5" />
          Load Demo Investigation
        </button>
      </header>

      {!investigations.length ? (
        <div className="border border-dashed border-mist bg-white/60 p-8">
          <p className="font-heading text-[18px] text-navy">No investigations saved yet</p>
          <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-slate-600">
            Open the Consequence Lab, adjust a scenario and save the result. Or load the demonstration investigation,
            which is a complete worked example of the free public transportation question.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            <Link
              to="/lab?scenario=transit"
              className="rounded-sm bg-navy px-4 py-2.5 text-[13px] font-medium text-paper transition-colors hover:bg-navy/90"
            >
              Open the Consequence Lab
            </Link>
            <button
              type="button"
              onClick={loadDemo}
              className="rounded-sm border border-navy/25 px-4 py-2.5 text-[13px] font-medium text-navy transition-colors hover:border-navy"
            >
              Load Demo Investigation
            </button>
          </div>
        </div>
      ) : null}

      <ul className="space-y-4">
        {investigations.map((investigation) => {
          const scenario = getScenario(investigation.scenarioId);
          const policy = scenario.alternatives.find((item) => item.id === investigation.policyId);
          const changedCount = Object.entries(investigation.params ?? {}).filter(
            ([key, value]) => scenario.baselineParams[key] !== value,
          ).length;

          return (
            <li
              key={investigation.id}
              className={`border bg-white p-5 ${investigation.isDemo ? 'border-ochre/60' : 'border-mist'}`}
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-[240px] flex-1">
                  {editingId === investigation.id ? (
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        value={draft}
                        onChange={(event) => setDraft(event.target.value)}
                        className="min-w-[220px] flex-1 rounded-sm border border-mist bg-paper/60 px-3 py-2 text-[13px] text-ink outline-none focus:border-teal"
                        aria-label="Investigation title"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          renameInvestigation(investigation.id, draft.trim());
                          setEditingId(null);
                          refresh();
                        }}
                        className="rounded-sm bg-navy px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-paper"
                      >
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="rounded-sm border border-mist px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600"
                      >
                        Cancel
                      </button>
                    </div>
                  ) : (
                    <h2 className="font-heading text-[19px] leading-snug text-navy">
                      {investigation.title}
                      {investigation.isDemo ? (
                        <span className="ml-3 rounded-sm border border-ochre/60 px-1.5 py-0.5 align-middle font-mono text-[9px] uppercase tracking-[0.1em] text-[#8a6420]">
                          demonstration
                        </span>
                      ) : null}
                    </h2>
                  )}

                  <p className="mt-2 font-mono text-[10.5px] uppercase tracking-[0.1em] text-slate-500">
                    {scenario.shortTitle} · {policy?.short ?? investigation.policyId} · {changedCount} parameter
                    {changedCount === 1 ? '' : 's'} off baseline
                  </p>
                  <p className="mt-1 text-[11.5px] text-slate-500">
                    Created {formatDate(investigation.createdAt)} · last updated {formatDate(investigation.updatedAt)}
                  </p>
                  {investigation.notes?.length ? (
                    <p className="mt-3 max-w-2xl text-[12.5px] leading-relaxed text-slate-600">
                      {investigation.notes[0]}
                    </p>
                  ) : null}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <Link
                    to={`/investigations/${investigation.id}`}
                    className="inline-flex items-center gap-1.5 rounded-sm bg-navy px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-paper transition-colors hover:bg-navy/90"
                  >
                    <Bookmark className="h-3 w-3" />
                    Open
                  </Link>
                  <Link
                    to={`/investigations/${investigation.id}/report`}
                    className="inline-flex items-center gap-1.5 rounded-sm border border-mist px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
                  >
                    <Printer className="h-3 w-3" />
                    Report
                  </Link>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingId(investigation.id);
                      setDraft(investigation.title);
                    }}
                    title="Rename"
                    className="rounded-sm border border-mist p-2 text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
                  >
                    <Pencil className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const copy = duplicateInvestigation(investigation.id);
                      refresh();
                      if (copy) navigate(`/investigations/${copy.id}`);
                    }}
                    title="Duplicate"
                    className="rounded-sm border border-mist p-2 text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                  {confirmId === investigation.id ? (
                    <span className="inline-flex items-center gap-2 rounded-sm border border-destructive/40 bg-destructive/5 px-2 py-1">
                      <span className="font-mono text-[10px] uppercase tracking-[0.08em] text-destructive">Delete?</span>
                      <button
                        type="button"
                        onClick={() => {
                          deleteInvestigation(investigation.id);
                          setConfirmId(null);
                          refresh();
                        }}
                        className="font-mono text-[10px] uppercase tracking-[0.08em] text-destructive underline"
                      >
                          Yes
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmId(null)}
                        className="font-mono text-[10px] uppercase tracking-[0.08em] text-slate-500 underline"
                      >
                        No
                      </button>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setConfirmId(investigation.id)}
                      title="Delete"
                      className="rounded-sm border border-mist p-2 text-slate-600 transition-colors hover:border-destructive/50 hover:text-destructive"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <section className="border-t border-mist pt-6">
        <p className="max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
          Investigations are stored in this browser only. Clearing site data removes them, so export a report for
          anything you need to keep. Reports recompute every figure from the saved parameters, so a report can never
          disagree with the Lab.
        </p>
      </section>
    </div>
  );
}