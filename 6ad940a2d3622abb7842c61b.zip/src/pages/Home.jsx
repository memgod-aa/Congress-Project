import { useMemo } from 'react';
import BranchMapPreview from '@/components/home/BranchMapPreview';
import Hero from '@/components/home/Hero';
import LevelsSection from '@/components/home/LevelsSection';
import ScenarioPreviews from '@/components/home/ScenarioPreviews';
import { effectiveParams, runScenario } from '@/lib/engine/registry';
import { EVIDENCE_LEVELS } from '@/lib/engine/types';

export default function Home() {
  const run = useMemo(() => runScenario('transit', effectiveParams('transit', 'free'), 'free'), []);

  return (
    <div>
      <Hero />

      <section>
        <BranchMapPreview />
      </section>

      <LevelsSection graph={run.graph} />

      <ScenarioPreviews />

      <section className="pt-10">
        <p className="sc text-oxblood">How to read any result here</p>
        <h2 className="mt-2 font-heading text-[30px] leading-[1.1] sm:text-[34px]">
          Four labels, so you always know what you are looking at
        </h2>
        <p className="mt-2.5 max-w-[600px] font-heading text-[15px] italic leading-[1.55] text-slate-700">
          No citation in this application is invented. Where a claim has no verified source, it is labelled as an
          assumption or a hypothesis instead of being presented as a finding.
        </p>

        <div className="mt-6 grid gap-5 sm:grid-cols-2 sm:gap-x-7">
          {EVIDENCE_LEVELS.map((evidence) => (
            <div key={evidence.id} className="border border-rule bg-panel p-4 shadow-paper">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full" style={{ background: evidence.color }} />
                <p className="sc sc-sm" style={{ color: evidence.color }}>
                  {evidence.label}
                </p>
              </div>
              <p className="mt-2 text-[13px] leading-[1.5] text-slate-700">{evidence.note}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}