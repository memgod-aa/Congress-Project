import { useMemo } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { FlaskConical, Printer } from 'lucide-react';
import MetricsGrid from '@/components/lab/MetricsGrid';
import SectionHeading from '@/components/so/SectionHeading';
import { format } from '@/lib/engine/format';
import { buildReport } from '@/lib/export/report';
import { DEMO_INVESTIGATION_ID, ensureDemoInvestigation, getInvestigation } from '@/lib/storage/investigations';

export default function InvestigationDetail() {
  const { investigationId } = useParams();
  const navigate = useNavigate();

  const record = useMemo(() => {
    if (investigationId === DEMO_INVESTIGATION_ID) return ensureDemoInvestigation();
    return getInvestigation(investigationId);
  }, [investigationId]);

  const report = useMemo(() => (record ? buildReport(record) : null), [record]);

  if (!record || !report) {
    return (
      <div className="space-y-5">
        <SectionHeading eyebrow="My Investigations" title="That investigation is not in this browser" level={1} />
        <p className="max-w-2xl text-[13px] leading-relaxed text-slate-600">
          Saved investigations live in the browser they were created in. This one could not be found — it may have been
          deleted, or it may have been saved on another device.
        </p>
        <Link
          to="/investigations"
          className="inline-flex rounded-sm bg-navy px-4 py-2.5 text-[13px] font-medium text-paper transition-colors hover:bg-navy/90"
        >
          Back to my investigations
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-10">
      <header>
        <SectionHeading
          eyebrow="Investigation"
          title={record.title}
          note={`${report.scenario.question} Policy: ${report.alternative.label}.`}
          level={1}
        />
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Link
            to={`/lab?scenario=${record.scenarioId}&policy=${record.policyId}&investigation=${record.id}`}
            className="inline-flex items-center gap-1.5 rounded-sm bg-navy px-4 py-2.5 text-[13px] font-medium text-paper transition-colors hover:bg-navy/90"
          >
            <FlaskConical className="h-3.5 w-3.5" />
            Reopen in the Consequence Lab
          </Link>
          <Link
            to={`/investigations/${record.id}/report`}
            className="inline-flex items-center gap-1.5 rounded-sm border border-navy/25 px-4 py-2.5 text-[13px] font-medium text-navy transition-colors hover:border-navy"
          >
            <Printer className="h-3.5 w-3.5" />
            Export report
          </Link>
          <button
            type="button"
            onClick={() => navigate('/investigations')}
            className="font-mono text-[10px] uppercase tracking-[0.12em] text-slate-500 transition-colors hover:text-navy"
          >
            All investigations
          </button>
        </div>
      </header>

      <section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Decision investigated</p>
          <p className="mt-3 border-l-2 border-ochre bg-white px-5 py-4 font-heading text-[18px] leading-snug text-navy">
            {report.scenario.decision}
          </p>
          <p className="mt-4 text-[12.5px] leading-relaxed text-slate-600">{report.scenario.settingNote}</p>
        </div>
        <dl className="border border-mist bg-white p-5">
          {[
            ['Scenario', report.scenario.shortTitle],
            ['Policy', report.alternative.short],
            ['Nodes in the map', String(report.nodes.length)],
            ['Assumptions', String(report.scenario.assumptions.length)],
            ['Created', new Date(record.createdAt).toLocaleString('en-US')],
            ['Last updated', new Date(record.updatedAt).toLocaleString('en-US')],
          ].map(([label, value]) => (
            <div key={label} className="border-b border-mist py-2.5 last:border-b-0">
              <dt className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">{label}</dt>
              <dd className="mt-1 text-[12.5px] text-navy">{value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Selected variables</p>
        <div className="mt-4 overflow-x-auto">
          <table className="w-full min-w-[520px] border-collapse text-left">
            <thead>
              <tr>
                <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Variable</th>
                <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">In this investigation</th>
                <th className="border-b border-navy/20 pb-2 text-[11px] font-normal text-slate-500">Scenario baseline</th>
              </tr>
            </thead>
            <tbody>
              {report.params.map((param) => (
                <tr key={param.key}>
                  <td className="border-b border-mist py-2.5 pr-4 text-[12.5px] text-ink">{param.label}</td>
                  <td className="tabular border-b border-mist py-2.5 pr-4 font-mono text-[12.5px] text-navy">
                    {format(param.value, param.format)}
                    {param.changed ? (
                      <span className="ml-2 rounded-sm border border-ochre/60 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-[0.08em] text-[#8a6420]">
                        changed
                      </span>
                    ) : null}
                  </td>
                  <td className="tabular border-b border-mist py-2.5 font-mono text-[12.5px] text-slate-500">
                    {format(param.baseline, param.format)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Results and calculations</p>
        <div className="mt-4">
          <MetricsGrid run={report.run} />
        </div>
      </section>

      {record.notes?.length ? (
        <section>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Your notes</p>
          <ul className="mt-3 space-y-2">
            {record.notes.map((note, index) => (
              <li key={index} className="border-l-2 border-teal bg-white px-4 py-3 text-[12.5px] leading-relaxed text-slate-600">
                {note}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {report.nodeNotes.length ? (
        <section>
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Notes attached to consequences</p>
          <ul className="mt-3 space-y-2">
            {report.nodeNotes.map((entry) => {
              const node = report.run.graph.byId.get(entry.nodeId);
              return (
                <li key={entry.nodeId} className="border border-mist bg-white p-4">
                  <p className="text-[12.5px] text-navy">{node?.title ?? entry.nodeId}</p>
                  <p className="mt-1.5 text-[12px] leading-relaxed text-slate-600">{entry.note?.text}</p>
                  {entry.note?.links?.[0]?.url ? (
                    <a
                      href={entry.note.links[0].url}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-1.5 inline-block text-[11.5px] text-teal underline decoration-teal/40"
                    >
                      {entry.note.links[0].label ?? entry.note.links[0].url}
                    </a>
                  ) : null}
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Alternatives kept with this investigation</p>
        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {report.alternatives.map((entry) => (
            <div key={entry.key} className="border border-mist bg-white p-4">
              <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{entry.scenario.shortTitle}</p>
              <p className="mt-1 font-heading text-[16px] text-navy">{entry.alternative.short}</p>
              <p className="mt-2 text-[12px] leading-relaxed text-slate-600">{entry.alternative.policySummary}</p>
              <Link
                to={`/lab?scenario=${entry.scenario.id}&policy=${entry.alternative.id}`}
                className="mt-3 inline-block font-mono text-[10px] uppercase tracking-[0.1em] text-teal transition-colors hover:text-navy"
              >
                Open in the Lab
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Unanswered questions carried forward</p>
        <ul className="mt-3 space-y-2">
          {report.questions.map((question, index) => (
            <li key={index} className="border-t border-mist pt-2.5 text-[12.5px] leading-relaxed text-slate-600">
              {question}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}