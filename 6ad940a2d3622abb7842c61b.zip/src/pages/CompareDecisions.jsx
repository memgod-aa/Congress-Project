import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { FlaskConical } from 'lucide-react';
import ColumnLists from '@/components/compare/ColumnLists';
import ComparisonTable from '@/components/compare/ComparisonTable';
import EvidenceMixChart from '@/components/compare/EvidenceMixChart';
import OutcomeChart from '@/components/compare/OutcomeChart';
import OutcomeSelector from '@/components/compare/OutcomeSelector';
import PolicyPicker from '@/components/compare/PolicyPicker';
import SectionHeading from '@/components/so/SectionHeading';
import {
  DEFAULT_SELECTION,
  buildComparison,
  columnRows,
  evidenceSummary,
  outcomeOptions,
  outcomeRows,
  parsePolicySelection,
  policySpecificNodes,
  resourcesAndUnintended,
  stakeholderCoverage,
  uncertainties,
  whatChanged,
} from '@/lib/engine/compare';
import { format } from '@/lib/engine/format';

export default function CompareDecisions() {
  const [searchParams, setSearchParams] = useSearchParams();
  const parsed = parsePolicySelection(searchParams.get('policies'));
  const selected = parsed ?? DEFAULT_SELECTION;
  const selectionKey = selected.join(',');

  const columns = useMemo(() => buildComparison(selected), [selectionKey]);
  const [chosen, setChosen] = useState([]);

  const options = useMemo(() => outcomeOptions(columns), [columns]);
  const kept = chosen.filter((label) => options.some((option) => option.label === label));
  const shown = kept.length ? kept : options.slice(0, 3).map((option) => option.label);

  const selectedRows = outcomeRows(columns, shown);
  const costRows = columnRows(columns, 'costs');
  const benefitRows = columnRows(columns, 'benefits');
  const changes = whatChanged(columns);
  const coverage = stakeholderCoverage(columns);
  const evidence = evidenceSummary(columns);
  const uncertain = uncertainties(columns);
  const specifics = policySpecificNodes(columns);
  const resources = resourcesAndUnintended(columns);

  const updateSelection = (next) => {
    setSearchParams(next.length ? { policies: next.join(',') } : {}, { replace: true });
  };

  return (
    <div className="space-y-12">
      <header>
        <SectionHeading
          eyebrow="Compare Decisions"
          title="Side by side, without a winner score"
          note="Policies are compared on the same baseline using the same deterministic engine. You choose which outcomes matter; the application deliberately does not combine them into a single number, because the outcomes point in different directions."
          level={1}
        />
      </header>

      <PolicyPicker selected={selected} onChange={updateSelection} />

      {columns.length < 2 ? (
        <p className="border border-mist bg-white p-5 text-[13px] text-slate-600">
          Two or three policies are needed for a comparison. Select another one above.
        </p>
      ) : (
        <>
          <section>
            <OutcomeSelector options={options} selected={shown} onChange={setChosen} />
            <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
              <OutcomeChart columns={columns} row={selectedRows[0]} />
              <ComparisonTable
                title="The outcomes you selected"
                rows={selectedRows}
                columns={columns}
                note="A marker shows the lowest or highest value in that row. It is not a judgement about which policy is better."
              />
            </div>
          </section>

          <ComparisonTable
            title="Direct costs"
            rows={costRows}
            columns={columns}
            note="Cost rows are the modelled money consequences of each policy. Values that a scenario does not model are marked rather than estimated."
          />

          <ComparisonTable
            title="Estimated benefits"
            rows={benefitRows}
            columns={columns}
            note="Benefits are modelled outputs, not validated outcomes. Read them alongside the evidence mix below."
          />

          <section>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Consequence branches</p>
            <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">
              Each policy brings consequences the others do not have. These are the nodes that appear under only one of
              the selected policies.
            </p>
            <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {specifics.map((group) => (
                <div key={group.key} className="border border-mist bg-white p-4">
                  <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{group.scenarioLabel}</p>
                  <p className="mt-1 font-heading text-[16px] text-navy">{group.label}</p>
                  <ul className="mt-3 space-y-2.5">
                    {group.nodes.map((node) => (
                      <li key={node.id} className="border-t border-mist pt-2">
                        <p className="text-[12.5px] leading-snug text-ink">{node.title}</p>
                        {node.value ? <p className="mt-1 font-mono text-[10.5px] text-slate-500">{node.value}</p> : null}
                      </li>
                    ))}
                    {!group.nodes.length ? (
                      <li className="text-[12.5px] text-slate-400">
                        No unique branches: this policy's consequences mirror the others in the selection.
                      </li>
                    ) : null}
                  </ul>
                  <Link
                    to={`/lab?scenario=${group.key.split(':')[0]}&policy=${group.key.split(':')[1]}`}
                    className="mt-3 inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.1em] text-teal transition-colors hover:text-navy"
                  >
                    <FlaskConical className="h-3 w-3" />
                    Inspect in the Lab
                  </Link>
                </div>
              ))}
            </div>
          </section>

          <ColumnLists
            title="Resource requirements"
            groups={resources.map((entry) => ({ key: entry.key, label: entry.label, scenarioLabel: entry.scenarioLabel, items: entry.resources }))}
          />

          <ColumnLists
            title="Potential unintended consequences"
            groups={resources.map((entry) => ({ key: entry.key, label: entry.label, scenarioLabel: entry.scenarioLabel, items: entry.unintended }))}
          />

          <section>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Stakeholders affected</p>
            <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">
              Counted from the nodes that reach each group under that policy, so a policy that looks cheaper can still
              touch more groups.
            </p>
            <div className="mt-4 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {coverage.map((entry) => (
                <div key={entry.key} className="border border-mist bg-white p-4">
                  <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{entry.scenarioLabel}</p>
                  <p className="mt-1 font-heading text-[16px] text-navy">{entry.label}</p>
                  <p className="mt-2 tabular font-mono text-[11.5px] text-slate-500">
                    {entry.total} groups · {entry.nodes} node links
                  </p>
                  <ul className="mt-3 space-y-1.5">
                    {entry.groups.map((group) => (
                      <li key={group.label} className="flex items-baseline justify-between gap-3 text-[12.5px] text-slate-600">
                        <span>{group.label}</span>
                        <span className="tabular font-mono text-[11px] text-navy">{group.count}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>

          <section className="grid gap-8 lg:grid-cols-[minmax(0,420px)_minmax(0,1fr)]">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Evidence quality</p>
              <p className="mt-2 text-[12px] leading-relaxed text-slate-600">
                Every node carries an evidence label. A policy supported mostly by assumed elasticity values is a
                different kind of claim from one whose numbers follow from arithmetic on your inputs.
              </p>
              <div className="mt-4">
                <EvidenceMixChart summary={evidence} />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[420px] border-collapse text-left">
                <thead>
                  <tr>
                    <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Policy</th>
                    <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Calculated</th>
                    <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Assumed</th>
                    <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Hypothesis</th>
                    <th className="border-b border-navy/20 pb-2 text-[11px] font-normal text-slate-500">Total nodes</th>
                  </tr>
                </thead>
                <tbody>
                  {evidence.map((entry) => (
                    <tr key={entry.key}>
                      <td className="border-b border-mist py-3 pr-4">
                        <span className="block font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{entry.scenarioLabel}</span>
                        <span className="text-[12.5px] text-navy">{entry.label}</span>
                      </td>
                      <td className="tabular border-b border-mist py-3 pr-4 font-mono text-[12.5px] text-slate-600">{entry.calculated}</td>
                      <td className="tabular border-b border-mist py-3 pr-4 font-mono text-[12.5px] text-slate-600">{entry.assumption}</td>
                      <td className="tabular border-b border-mist py-3 pr-4 font-mono text-[12.5px] text-slate-600">{entry.hypothesis}</td>
                      <td className="tabular border-b border-mist py-3 font-mono text-[12.5px] text-navy">{entry.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <ColumnLists
            title="Key uncertainties"
            note="Uncertainty is listed, not resolved: these are the mechanisms the models flag as unmeasured."
            groups={uncertain.map((entry) => ({
              key: entry.key,
              label: entry.label,
              scenarioLabel: entry.scenarioLabel,
              items: [...entry.questions, ...entry.hypothesisNodes.map((title) => `${title} — flagged as an unverified hypothesis.`)],
            }))}
          />

          <section>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">What changed?</p>
            <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">
              The inputs that differ from each scenario's baseline, and the assumptions each policy relies on. These are
              the reasons the results differ — not the results themselves.
            </p>

            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[520px] border-collapse text-left">
                <thead>
                  <tr>
                    <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Input</th>
                    {columns.map((column) => (
                      <th key={column.key} className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">
                        {column.policyLabel}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {changes.inputMatrix.map((row) => (
                    <tr key={row.label}>
                      <td className="border-b border-mist py-3 pr-4 text-[12.5px] text-ink">{row.label}</td>
                      {row.cells.map((cell, index) => (
                        <td key={columns[index].key} className="border-b border-mist py-3 pr-4">
                          {cell ? (
                            <span className="font-mono text-[12px] text-navy">
                              {format(cell.value, cell.format)}
                              <span className="ml-2 text-slate-400">baseline {format(cell.baseline, cell.format)}</span>
                            </span>
                          ) : (
                            <span className="font-mono text-[12px] text-slate-400">at baseline</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  ))}
                  {!changes.inputMatrix.length ? (
                    <tr>
                      <td colSpan={columns.length + 1} className="border-b border-mist py-3 text-[12.5px] text-slate-500">
                        Every selected policy currently sits at its scenario baseline, so no input differs.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>

            <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {changes.assumptions.map((entry) => (
                <div key={entry.key} className="border border-mist bg-white p-4">
                  <p className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">{entry.scenarioLabel}</p>
                  <p className="mt-1 font-heading text-[16px] text-navy">{entry.label}</p>
                  <ul className="mt-3 space-y-2">
                    {entry.items.map((item, index) => (
                      <li key={index} className="text-[12.5px] leading-relaxed text-slate-600">
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        </>
      )}
    </div>
  );
}