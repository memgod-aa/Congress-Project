import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, FlaskConical, GitCompare } from 'lucide-react';
import SectionHeading from '@/components/so/SectionHeading';
import { countByLevel } from '@/lib/engine/graph';
import { baselineParams, listScenarios, runScenario } from '@/lib/engine/registry';

function ScenarioCard({ scenario }) {
  const run = useMemo(() => runScenario(scenario.id, baselineParams(scenario.id), 'baseline'), [scenario.id]);
  const levels = countByLevel(run.graph.nodes);
  const categories = [...new Set(run.graph.nodes.map((node) => node.category))];

  return (
    <article className="flex flex-col border border-mist bg-white p-6">
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-teal">{scenario.shortTitle}</p>
      <h3 className="mt-3 font-heading text-[21px] leading-snug text-navy">{scenario.question}</h3>
      <p className="mt-3 text-[12.5px] leading-relaxed text-slate-600">{scenario.setting}</p>

      <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-3">
        {scenario.baselineConditions.slice(0, 4).map((item) => (
          <div key={item.label} className="border-t border-mist pt-2.5">
            <dt className="text-[11px] text-slate-500">{item.label}</dt>
            <dd className="tabular mt-1 font-mono text-[12.5px] text-navy">{item.value}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-5 flex flex-wrap gap-x-6 gap-y-2 font-mono text-[10.5px] uppercase tracking-[0.08em] text-slate-500">
        <span>{run.graph.nodes.length} consequence nodes</span>
        <span>{scenario.alternatives.length} policies</span>
        <span>{scenario.assumptions.length} assumptions</span>
      </div>
      <p className="mt-2 text-[11.5px] leading-relaxed text-slate-500">
        {levels[1]} first-order · {levels[2]} second-order · {levels[3]} third-order · {categories.length} categories
      </p>

      <div className="mt-6 flex flex-1 flex-wrap items-end gap-3 border-t border-mist pt-4">
        <Link
          to={`/scenario/${scenario.id}`}
          className="inline-flex items-center gap-1.5 rounded-sm border border-navy bg-navy px-3.5 py-2 text-[12.5px] font-medium text-paper transition-colors hover:bg-navy/90"
        >
          Open the simulation
          <ArrowRight className="h-3 w-3" />
        </Link>
        <Link
          to={`/lab?scenario=${scenario.id}&policy=${scenario.defaultPolicy}`}
          className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500 transition-colors hover:text-navy"
        >
          <FlaskConical className="h-3 w-3" />
          Consequence Lab
        </Link>
        <Link
          to={`/compare?policies=${scenario.id}:${scenario.defaultPolicy}`}
          className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500 transition-colors hover:text-navy"
        >
          <GitCompare className="h-3 w-3" />
          Compare
        </Link>
      </div>
    </article>
  );
}

export default function ExploreScenarios() {
  const scenarios = listScenarios();

  return (
    <div className="space-y-10">
      <SectionHeading
        eyebrow="Explore Scenarios"
        title="Real-world decisions, modelled as systems"
        note="Every scenario opens as a working simulation: a decision, its baseline conditions, a branching consequence map, adjustable variables, alternative policies and a stakeholder analysis. Nothing here is a forecast — the settings are fictional and every assumption is labelled."
        level={1}
      />

      <div className="grid gap-5 lg:grid-cols-2">
        {scenarios.map((scenario) => (
          <ScenarioCard key={scenario.id} scenario={scenario} />
        ))}
      </div>

      <section className="border border-mist bg-white p-6">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">What you can do with a scenario</p>
        <div className="mt-4 grid gap-x-8 gap-y-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { title: 'Follow the branches', text: 'Expand first-, second- and third-order effects and follow the connections between them.' },
            { title: 'Change the decision', text: 'Switch policy, then move the variables and watch the model recalculate.' },
            { title: 'Inspect the reasoning', text: 'Open any node for its calculation, its assumptions and its evidence status.' },
            { title: 'Save and export', text: 'Keep an investigation in this browser and export it as a printable report or structured data.' },
          ].map((item) => (
            <div key={item.title} className="border-t border-navy/15 pt-3">
              <p className="font-heading text-[16px] text-navy">{item.title}</p>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-600">{item.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}