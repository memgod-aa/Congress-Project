import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Bookmark, GitCompare, RotateCcw, SlidersHorizontal } from 'lucide-react';
import GraphPanel from '@/components/graph/GraphPanel';
import ChangeExplainer from '@/components/lab/ChangeExplainer';
import MetricsGrid from '@/components/lab/MetricsGrid';
import PolicySelector from '@/components/lab/PolicySelector';
import SummaryPanel from '@/components/lab/SummaryPanel';
import VariableControls from '@/components/lab/VariableControls';
import ScenarioFacts from '@/components/ScenarioFacts';
import SectionHeading from '@/components/so/SectionHeading';
import StakeholderPanel from '@/components/stakeholders/StakeholderPanel';
import { clamp, format } from '@/lib/engine/format';
import { effectiveParams, getScenario, runScenario } from '@/lib/engine/registry';
import { getInvestigation, newId, saveInvestigation } from '@/lib/storage/investigations';

const DEFAULT_VIEW = { collapsed: [], categories: [], highlight: 'all' };

export default function ConsequenceLab() {
  const [searchParams] = useSearchParams();
  const scenarioId = searchParams.get('scenario') ?? 'transit';
  const scenario = getScenario(scenarioId);
  const investigationId = searchParams.get('investigation');
  const nodeParam = searchParams.get('node');

  const stored = useMemo(() => (investigationId ? getInvestigation(investigationId) : null), [investigationId]);
  const urlPolicy = searchParams.get('policy') ?? scenario.defaultPolicy;
  const [policyId, setPolicyId] = useState(stored?.policyId ?? urlPolicy);
  const stateKey = `${scenarioId}:${policyId}:${investigationId ?? 'fresh'}`;

  const preset = useMemo(() => effectiveParams(scenarioId, policyId), [scenarioId, policyId]);
  const initialParams = useMemo(() => ({ ...preset, ...(stored?.params ?? {}) }), [preset, stored]);

  const [params, setParams] = useState(() => initialParams);
  const lastKey = useRef(stateKey);
  const [errors, setErrors] = useState({});
  const [selectedId, setSelectedId] = useState(nodeParam ?? stored?.selectedNodeId ?? 'decision');
  const [view, setView] = useState(() => stored?.graphState ?? DEFAULT_VIEW);
  const [stakeholderId, setStakeholderId] = useState(null);
  const [title, setTitle] = useState(() => stored?.title ?? `${scenario.shortTitle} — lab session`);
  const [saved, setSaved] = useState(null);

  useEffect(() => {
    setPolicyId(stored?.policyId ?? urlPolicy);
  }, [stored, urlPolicy, scenarioId]);

  useEffect(() => {
    if (lastKey.current !== stateKey) {
      lastKey.current = stateKey;
      setParams(initialParams);
      setErrors({});
      setSaved(null);
    }
  }, [stateKey, initialParams]);

  useEffect(() => {
    if (nodeParam) setSelectedId(nodeParam);
  }, [nodeParam]);

  const run = useMemo(() => runScenario(scenarioId, params, policyId), [scenarioId, params, policyId]);
  const stakeholder = (scenario.stakeholders ?? []).find((entry) => entry.id === stakeholderId) ?? null;

  const setValue = useCallback(
    (key, raw) => {
      const variable = scenario.variables.find((entry) => entry.key === key);
      let value = raw;
      let error = null;
      if (variable && variable.control !== 'select') {
        if (value < variable.min || value > variable.max) {
          error = `${variable.label} must stay between ${format(variable.min, variable.format)} and ${format(
            variable.max,
            variable.format,
          )}. Using the nearest valid value.`;
          value = clamp(value, variable.min, variable.max);
        }
      }
      setErrors((previous) => ({ ...previous, [key]: error }));
      setParams((previous) => ({ ...previous, [key]: value }));
    },
    [scenario],
  );

  // Switching scenario renders once with the previous scenario's parameter
  // keys. Filling any gap from the policy preset keeps every control defined.
  const controlValues = useMemo(() => {
    const merged = {};
    scenario.variables.forEach((variable) => {
      const value = params[variable.key];
      merged[variable.key] = typeof value === 'number' ? value : preset[variable.key] ?? scenario.baselineParams[variable.key];
    });
    return merged;
  }, [params, preset, scenario]);

  const resetToBaseline = () => {
    setParams({ ...scenario.baselineParams });
    setErrors({});
  };

  const resetToPreset = () => {
    setParams({ ...preset });
    setErrors({});
  };

  const saveCurrent = () => {
    const record = saveInvestigation({
      id: stored?.id ?? newId(),
      title: title.trim() || `${scenario.shortTitle} — lab session`,
      scenarioId,
      policyId,
      params,
      graphState: view,
      selectedNodeId: selectedId,
      selectedAlternatives: stored?.selectedAlternatives ?? [`${scenarioId}:${policyId}`],
      stakeholderId,
      notes: stored?.notes ?? [],
      createdAt: stored?.createdAt,
      isDemo: false,
    });
    setSaved(record);
  };

  return (
    <div className="space-y-10">
      <header>
        <SectionHeading
          eyebrow="Consequence Lab"
          title={scenario.title}
          note={scenario.settingNote}
          level={1}
        />
        <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-[10px] uppercase tracking-[0.12em]">
          <Link to={`/scenario/${scenarioId}`} className="text-teal transition-colors hover:text-navy">
            Scenario overview
          </Link>
          <Link to={`/compare?policies=${scenarioId}:${policyId}`} className="inline-flex items-center gap-1.5 text-teal transition-colors hover:text-navy">
            <GitCompare className="h-3 w-3" />
            Compare policies
          </Link>
          <span className="text-slate-500">Deterministic model · same inputs, same outputs</span>
        </div>
      </header>

      <PolicySelector scenario={scenario} policyId={policyId} onChange={setPolicyId} />

      <div className="grid gap-8 lg:grid-cols-[370px_minmax(0,1fr)]">
        <div className="space-y-5">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-3.5 w-3.5 text-slate-500" />
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Scenario variables</p>
          </div>
          <VariableControls
            scenario={scenario}
            params={controlValues}
            onChange={setValue}
            onResetVariable={(key) => setValue(key, scenario.baselineParams[key])}
            errors={errors}
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={resetToBaseline}
              className="inline-flex items-center gap-1.5 rounded-sm border border-navy bg-white px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-navy transition-colors hover:bg-navy hover:text-paper"
            >
              <RotateCcw className="h-3 w-3" />
              Reset to baseline
            </button>
            <button
              type="button"
              onClick={resetToPreset}
              className="rounded-sm border border-mist bg-white px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
            >
              Reset to this policy
            </button>
          </div>
        </div>

        <div className="space-y-7">
          <SummaryPanel run={run} />
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
              Modelled outputs — each shown against the baseline
            </p>
            <div className="mt-4">
              <MetricsGrid run={run} />
            </div>
          </div>
        </div>
      </div>

      <ChangeExplainer run={run} />

      <section>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Consequence map</p>
            <h2 className="mt-1.5 font-heading text-[22px] text-navy">The decision and everything downstream of it</h2>
          </div>
          <p className="max-w-md text-[12px] leading-relaxed text-slate-500">
            The map recalculates as you move the sliders: node titles, values and directions of effect all come from the
            current settings.
          </p>
        </div>
        <GraphPanel
          className="mt-5"
          run={run}
          view={view}
          onViewChange={setView}
          selectedId={selectedId}
          onSelect={setSelectedId}
          stakeholder={stakeholder}
          onClearStakeholder={() => {
            setStakeholderId(null);
            setView((previous) => ({ ...previous, highlight: 'all' }));
          }}
          height={600}
        />
      </section>

      <StakeholderPanel
        run={run}
        selectedId={stakeholderId}
        onSelect={(id) => {
          setStakeholderId(id);
          setView((previous) => ({ ...previous, highlight: id ? 'stakeholder' : 'all' }));
        }}
        highlightOnMap={view.highlight === 'stakeholder' && Boolean(stakeholder)}
        onToggleHighlight={() =>
          setView((previous) => ({ ...previous, highlight: previous.highlight === 'stakeholder' ? 'all' : 'stakeholder' }))
        }
      />

      <section className="border border-mist bg-white p-5">
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Save this investigation</p>
        <p className="mt-2 max-w-2xl text-[12.5px] leading-relaxed text-slate-600">
          Saving keeps the parameters, the map state, the selected policy and any notes you have added on nodes. Stored
          in this browser, with no account needed.
        </p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            className="min-w-[240px] flex-1 rounded-sm border border-mist bg-paper/60 px-3 py-2 text-[12.5px] text-ink outline-none focus:border-teal"
            aria-label="Investigation title"
          />
          <button
            type="button"
            onClick={saveCurrent}
            className="inline-flex items-center gap-1.5 rounded-sm bg-navy px-4 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-paper transition-colors hover:bg-navy/90"
          >
            <Bookmark className="h-3 w-3" />
            {stored ? 'Update saved investigation' : 'Save investigation'}
          </button>
        </div>
        {saved ? (
          <p className="mt-3 text-[12.5px] text-slate-600">
            Saved as “{saved.title}”.{' '}
            <Link to={`/investigations/${saved.id}`} className="text-teal underline decoration-teal/40">
              Open it
            </Link>{' '}
            or{' '}
            <Link to={`/investigations/${saved.id}/report`} className="text-teal underline decoration-teal/40">
              export a report
            </Link>
            .
          </p>
        ) : null}
      </section>

      <details className="border border-mist bg-white p-5">
        <summary className="cursor-pointer font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
          Baseline conditions and the full assumption register
        </summary>
        <div className="mt-5">
          <ScenarioFacts scenario={scenario} />
        </div>
      </details>
    </div>
  );
}