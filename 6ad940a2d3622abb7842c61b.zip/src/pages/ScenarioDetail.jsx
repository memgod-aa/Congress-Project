import { useEffect, useMemo, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { FlaskConical, GitCompare } from 'lucide-react';
import GraphPanel from '@/components/graph/GraphPanel';
import ScenarioFacts from '@/components/ScenarioFacts';
import SectionHeading from '@/components/so/SectionHeading';
import StakeholderPanel from '@/components/stakeholders/StakeholderPanel';
import { effectiveParams, getScenario, runScenario } from '@/lib/engine/registry';

function AlternativeCard({ scenario, alternative }) {
  return (
    <article className="flex flex-col border border-mist bg-white p-5">
      <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-teal">
        {alternative.isBaseline ? 'Reference case' : 'Alternative policy'}
      </p>
      <h3 className="mt-2.5 font-heading text-[18px] leading-snug text-navy">{alternative.label}</h3>
      <p className="mt-3 text-[12.5px] leading-relaxed text-slate-600">{alternative.policySummary}</p>

      <dl className="mt-4 space-y-3 text-[12px]">
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">Key assumptions</dt>
          <dd className="mt-1 space-y-1">
            {alternative.keyAssumptions.map((item, index) => (
              <p key={index} className="text-slate-600">
                {item}
              </p>
            ))}
          </dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">Resources required</dt>
          <dd className="mt-1 space-y-1">
            {alternative.resources.map((item, index) => (
              <p key={index} className="text-slate-600">
                {item}
              </p>
            ))}
          </dd>
        </div>
        <div>
          <dt className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">Potential unintended consequences</dt>
          <dd className="mt-1 space-y-1">
            {alternative.unintended.map((item, index) => (
              <p key={index} className="text-slate-600">
                {item}
              </p>
            ))}
          </dd>
        </div>
      </dl>

      <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-mist pt-4">
        <Link
          to={`/lab?scenario=${scenario.id}&policy=${alternative.id}`}
          className="inline-flex items-center gap-1.5 rounded-sm border border-navy bg-navy px-3 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-paper transition-colors hover:bg-navy/90"
        >
          <FlaskConical className="h-3 w-3" />
          Open in the Lab
        </Link>
        <Link to={`/compare?policies=${scenario.id}:${alternative.id}`} className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500 transition-colors hover:text-navy">
          Compare
        </Link>
      </div>
    </article>
  );
}

export default function ScenarioDetail() {
  const { scenarioId } = useParams();
  const [searchParams] = useSearchParams();
  const scenario = getScenario(scenarioId);
  const expand = searchParams.get('expand');

  const run = useMemo(
    () => runScenario(scenarioId, effectiveParams(scenarioId, scenario.defaultPolicy), scenario.defaultPolicy),
    [scenarioId, scenario],
  );
  const levelOneIds = useMemo(() => run.graph.nodes.filter((node) => node.level === 1).map((node) => node.id), [run.graph]);

  const [view, setView] = useState(() => ({
    collapsed: expand === '1' ? run.graph.nodes.filter((node) => node.level === 1).map((node) => node.id) : [],
    categories: [],
    highlight: 'all',
  }));
  const [selectedId, setSelectedId] = useState('decision');
  const [stakeholderId, setStakeholderId] = useState(null);

  useEffect(() => {
    if (expand === 'all') setView((previous) => ({ ...previous, collapsed: [] }));
    if (expand === '1') setView((previous) => ({ ...previous, collapsed: levelOneIds }));
  }, [expand, levelOneIds]);

  const stakeholder = (scenario.stakeholders ?? []).find((entry) => entry.id === stakeholderId) ?? null;

  return (
    <div className="space-y-12">
      <header>
        <SectionHeading eyebrow={scenario.shortTitle} title={scenario.title} note={scenario.setting} level={1} />
        <div className="mt-6 border-l-2 border-ochre bg-white px-5 py-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">The initial decision</p>
          <p className="mt-2 font-heading text-[18px] leading-snug text-navy">{scenario.decision}</p>
          <p className="mt-2 text-[12.5px] leading-relaxed text-slate-600">{scenario.settingNote}</p>
        </div>
        <div className="mt-5 flex flex-wrap items-center gap-3">
          <Link
            to={`/lab?scenario=${scenario.id}&policy=${scenario.defaultPolicy}`}
            className="inline-flex items-center gap-1.5 rounded-sm bg-navy px-4 py-2.5 text-[13px] font-medium text-paper transition-colors hover:bg-navy/90"
          >
            <FlaskConical className="h-3.5 w-3.5" />
            Open this scenario in the Lab
          </Link>
          <Link
            to={`/compare?policies=${scenario.id}:${scenario.defaultPolicy}`}
            className="inline-flex items-center gap-1.5 rounded-sm border border-navy/25 px-4 py-2.5 text-[13px] font-medium text-navy transition-colors hover:border-navy"
          >
            <GitCompare className="h-3.5 w-3.5" />
            Compare its policies
          </Link>
        </div>
      </header>

      <section>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Consequence map</p>
            <h2 className="mt-1.5 font-heading text-[22px] text-navy">Expand the branches, inspect any node</h2>
          </div>
          <p className="max-w-md text-[12px] leading-relaxed text-slate-500">
            Showing the “{scenario.alternatives.find((a) => a.id === scenario.defaultPolicy)?.short}” policy. Change the
            policy and variables in the Consequence Lab.
          </p>
        </div>
        <GraphPanel
          className="mt-5"
          run={run}
          view={view}
          onViewChange={setView}
          selectedId={selectedId}
          onSelect={setSelectedId}
          stakeholder={stakeholder}
          onClearStakeholder={() => {
            setStakeholderId(null);
            setView((previous) => ({ ...previous, highlight: 'all' }));
          }}
          height={600}
        />
      </section>

      <ScenarioFacts scenario={scenario} />

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Alternative policies</p>
        <h2 className="mt-2 font-heading text-[22px] text-navy">There is no automatically correct answer</h2>
        <p className="mt-2 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
          Each policy carries different assumptions, different calculations and different consequence branches. Compare
          them on the outcomes you actually care about.
        </p>
        <div className="mt-5 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {scenario.alternatives.map((alternative) => (
            <AlternativeCard key={alternative.id} scenario={scenario} alternative={alternative} />
          ))}
        </div>
      </section>

      <StakeholderPanel
        run={run}
        selectedId={stakeholderId}
        onSelect={(id) => {
          setStakeholderId(id);
          setView((previous) => ({ ...previous, highlight: id ? 'stakeholder' : 'all' }));
        }}
        highlightOnMap={view.highlight === 'stakeholder' && Boolean(stakeholder)}
        onToggleHighlight={() =>
          setView((previous) => ({ ...previous, highlight: previous.highlight === 'stakeholder' ? 'all' : 'stakeholder' }))
        }
      />
    </div>
  );
}