import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';
import SectionHeading from '@/components/so/SectionHeading';
import { DEMO_STEPS } from '@/lib/demo';
import { EVIDENCE_LEVELS, LEVELS } from '@/lib/engine/types';

export default function About() {
  return (
    <div className="space-y-12">
      <header>
        <SectionHeading
          eyebrow="About"
          title="Systems thinking you can operate, not just read about"
          note="SecondOrder is an interactive decision-simulation platform. Its purpose is to make the indirect consequences of a decision explorable: you choose a decision, move its assumptions, and watch a branching consequence map recalculate."
          level={1}
        />
      </header>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">The three orders of effect</p>
        <div className="mt-4 grid gap-x-8 gap-y-5 md:grid-cols-3">
          {LEVELS.filter((level) => level.level > 0).map((level) => (
            <div key={level.level} className="border-t-2 border-navy/15 pt-3">
              <p className="font-heading text-[17px] text-navy">{level.label}</p>
              <p className="mt-2 text-[12.5px] leading-relaxed text-slate-600">{level.note}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">How the consequence engine works</p>
        <div className="mt-4 grid gap-x-10 gap-y-6 lg:grid-cols-2">
          <div className="space-y-4 text-[13px] leading-relaxed text-slate-600">
            <p>
              Consequences are stored as a directed graph. Each node declares its parents, its category, its type, its
              direction of effect, the variables that influence it, the assumptions it rests on and its evidence status.
            </p>
            <p>
              <span className="text-navy">Levels are derived, not declared.</span> A node's order of effect is computed
              from its parent chain, so the map cannot show an effect claiming to be second-order when its own parents
              say otherwise. Nodes that appear only under certain conditions — a funding gap, a capacity breach — enter
              and leave the map as the model requires.
            </p>
            <p>
              <span className="text-navy">The calculation layer is separate from the data.</span> Each scenario is a
              module: its illustrative values, its assumptions and its formulas live in one file, and its graph nodes live
              in another. Adding a scenario does not require changing the engine or the interface.
            </p>
          </div>
          <div className="space-y-4 text-[13px] leading-relaxed text-slate-600">
            <p>
              <span className="text-navy">Calculations are deterministic and dependency-aware.</span> The same inputs
              always produce the same outputs. Where outputs depend on each other in a loop — in the transit scenario,
              lost fare revenue limits how much service can be funded, and funded service changes ridership and therefore
              revenue again — the engine solves the loop iteratively to a stable point instead of relying on the order you
              happened to move the controls.
            </p>
            <p>
              <span className="text-navy">Attribution is computed.</span> The “What changed and why” panel is built from
              each output's declared drivers. It lists the inputs that actually moved, with their before and after values,
              rather than offering a narrative explanation written by hand.
            </p>
            <p>
              Where an outcome cannot be calculated, the node says so: a range, a qualitative direction, or an explicit
              statement that no quantity is modelled.
            </p>
          </div>
        </div>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">Our rule about evidence</p>
        <p className="mt-3 max-w-3xl text-[13px] leading-relaxed text-slate-600">
          No citation, statistic or research finding in this application is invented. Every claim carries one of four
          labels, and where a verified source does not exist the claim is presented as an assumption or a question
          instead. You can attach your own notes and evidence links to any consequence, and they appear in exported
          reports.
        </p>
        <div className="mt-5 grid gap-x-8 gap-y-5 sm:grid-cols-2">
          {EVIDENCE_LEVELS.map((evidence) => (
            <div key={evidence.id} className="border-t border-mist pt-3">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ background: evidence.color }} />
                <p className="font-mono text-[10.5px] uppercase tracking-[0.12em]" style={{ color: evidence.color }}>
                  {evidence.label}
                </p>
              </div>
              <p className="mt-2 text-[12.5px] leading-relaxed text-slate-600">{evidence.note}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-slate-500">What these models do not do</p>
        <ul className="mt-4 grid gap-x-10 gap-y-2.5 md:grid-cols-2">
          {[
            'They do not predict real outcomes. Every setting is fictional and every value is illustrative.',
            'They do not model emissions, congestion or environmental quantities. Those effects are described qualitatively.',
            'They do not measure learning, health or wellbeing. Those appear on the maps as questions.',
            'They do not claim scientific validation, and they do not replace a study, a survey or a costing exercise.',
            'They do not attach citations. A research-supported label would require a source, and none is supplied here.',
            'They do not hide tradeoffs behind a single score. There is no winner calculation anywhere in the application.',
          ].map((item) => (
            <li key={item} className="border-t border-mist pt-2.5 text-[12.5px] leading-relaxed text-slate-600">
              {item}
            </li>
          ))}
        </ul>
      </section>

      <section className="border border-mist bg-white p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ochre">Competition demonstration</p>
            <h2 className="mt-2 font-heading text-[22px] text-navy">Walk the whole application in about three minutes</h2>
            <p className="mt-2 max-w-2xl text-[12.5px] leading-relaxed text-slate-600">
              The demonstration loads a complete worked investigation of free public transportation and then steps through
              the application, using the real models. No account or setup is required.
            </p>
          </div>
          <Link
            to="/?demo=1"
            className="inline-flex items-center gap-2 rounded-sm border border-ochre bg-ochre/10 px-4 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.12em] text-[#8a6420] transition-colors hover:bg-ochre/20"
          >
            <Play className="h-3.5 w-3.5" />
            Launch Demo
          </Link>
        </div>
        <ol className="mt-5 grid gap-x-8 gap-y-3 md:grid-cols-2">
          {DEMO_STEPS.map((step) => (
            <li key={step.id} className="border-t border-mist pt-2.5">
              <p className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">Step {step.id}</p>
              <p className="mt-1 text-[12.5px] font-medium text-navy">{step.title}</p>
              <p className="mt-1 text-[12px] leading-relaxed text-slate-600">{step.instruction}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="border-t border-mist pt-6">
        <p className="max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
          No account is needed to use SecondOrder. Saved investigations and your node notes are kept in this browser, so
          they stay on this device and can be exported at any time.
        </p>
      </section>
    </div>
  );
}