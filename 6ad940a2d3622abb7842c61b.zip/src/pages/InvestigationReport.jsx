import { useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Check, Copy, Download, FileJson, FileSpreadsheet, Printer } from 'lucide-react';
import GraphPanel from '@/components/graph/GraphPanel';
import { Chip, EvidenceBadge } from '@/components/so/Chip';
import { format } from '@/lib/engine/format';
import { DIRECTION_LABEL, LEVELS } from '@/lib/engine/types';
import { buildReport, download, exportPdf, toCsv, toJson, toPlainText } from '@/lib/export/report';
import { DEMO_INVESTIGATION_ID, ensureDemoInvestigation, getInvestigation } from '@/lib/storage/investigations';

const DEFAULT_VIEW = { collapsed: [], categories: [], highlight: 'all' };

function Section({ title, note, children }) {
  return (
    <section className="print-break mt-8 border-t border-mist pt-5">
      <h2 className="font-heading text-[19px] text-navy">{title}</h2>
      {note ? <p className="mt-2 max-w-3xl text-[12px] leading-relaxed text-slate-600">{note}</p> : null}
      <div className="mt-4">{children}</div>
    </section>
  );
}

export default function InvestigationReport() {
  const { investigationId } = useParams();
  const [status, setStatus] = useState(null);

  const record = useMemo(() => {
    if (investigationId === DEMO_INVESTIGATION_ID) return ensureDemoInvestigation();
    return getInvestigation(investigationId);
  }, [investigationId]);
  const report = useMemo(() => (record ? buildReport(record) : null), [record]);

  if (!record || !report) {
    return (
      <div className="space-y-5">
        <h1 className="font-heading text-[26px] text-navy">Report unavailable</h1>
        <p className="max-w-2xl text-[13px] leading-relaxed text-slate-600">
          This investigation could not be found in this browser, so there is nothing to report.
        </p>
        <Link to="/investigations" className="text-[13px] text-teal underline decoration-teal/40">
          Back to my investigations
        </Link>
      </div>
    );
  }

  const slug = (record.title || 'secondorder-report').replace(/[^\w-]+/g, '-').toLowerCase();

  const copySummary = async () => {
    try {
      await navigator.clipboard.writeText(toPlainText(report));
      setStatus('Summary copied to the clipboard.');
    } catch {
      setStatus('Copying was blocked by the browser. Download the JSON instead.');
    }
  };

  const savePdf = async () => {
    setStatus('Building the PDF…');
    try {
      await exportPdf(report);
      setStatus('PDF downloaded.');
    } catch {
      setStatus('The PDF export failed. Use Print and choose “Save as PDF” instead.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-wrap items-center gap-3 border-b border-mist pb-5">
        <Link to={`/investigations/${record.id}`} className="font-mono text-[10px] uppercase tracking-[0.12em] text-slate-500 transition-colors hover:text-navy">
          Back to the investigation
        </Link>
        <span className="flex-1" />
        <button
          type="button"
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 rounded-sm bg-navy px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-paper transition-colors hover:bg-navy/90"
        >
          <Printer className="h-3 w-3" />
          Print or save as PDF
        </button>
        <button
          type="button"
          onClick={savePdf}
          className="inline-flex items-center gap-1.5 rounded-sm border border-mist px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
        >
          <Download className="h-3 w-3" />
          Structured PDF
        </button>
        <button
          type="button"
          onClick={() => download(`${slug}.json`, toJson(report), 'application/json')}
          className="inline-flex items-center gap-1.5 rounded-sm border border-mist px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
        >
          <FileJson className="h-3 w-3" />
          JSON
        </button>
        <button
          type="button"
          onClick={() => download(`${slug}.csv`, toCsv(report), 'text/csv')}
          className="inline-flex items-center gap-1.5 rounded-sm border border-mist px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
        >
          <FileSpreadsheet className="h-3 w-3" />
          CSV
        </button>
        <button
          type="button"
          onClick={copySummary}
          className="inline-flex items-center gap-1.5 rounded-sm border border-mist px-3.5 py-2 font-mono text-[10px] uppercase tracking-[0.08em] text-slate-600 transition-colors hover:border-navy/40 hover:text-navy"
        >
          <Copy className="h-3 w-3" />
          Copy summary
        </button>
      </div>

      {status ? (
        <p className="no-print inline-flex items-center gap-2 text-[12px] text-slate-600">
          <Check className="h-3.5 w-3.5 text-teal" />
          {status}
        </p>
      ) : null}

      <article className="print-sheet border border-mist bg-white p-8">
        <header className="border-b border-mist pb-5">
          <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-teal">SecondOrder — investigation report</p>
          <h1 className="mt-3 font-heading text-[30px] leading-tight text-navy">{record.title}</h1>
          <p className="mt-3 text-[13px] leading-relaxed text-slate-600">
            {report.scenario.question} · Policy: {report.alternative.label}
          </p>
          <p className="mt-1 font-mono text-[10.5px] uppercase tracking-[0.1em] text-slate-500">
            Generated {new Date(report.generatedAt).toLocaleString('en-US')} · illustrative model · assumptions labelled
          </p>
        </header>

        <Section title="Decision investigated">
          <p className="border-l-2 border-ochre pl-4 font-heading text-[17px] leading-snug text-navy">
            {report.scenario.decision}
          </p>
          <p className="mt-3 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">{report.scenario.settingNote}</p>
          <p className="mt-2 max-w-3xl text-[12.5px] leading-relaxed text-slate-600">
            Policy summary: {report.alternative.policySummary}
          </p>
        </Section>

        <Section title="Baseline conditions">
          <table className="w-full border-collapse text-left">
            <tbody>
              {report.scenario.baselineConditions.map((item) => (
                <tr key={item.label}>
                  <td className="border-b border-mist py-2 pr-4 text-[12px] text-slate-500">{item.label}</td>
                  <td className="border-b border-mist py-2 font-mono text-[12px] text-navy">
                    {item.value}
                    {item.note ? <span className="ml-2 text-slate-400">{item.note}</span> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        <Section title="Selected variables">
          <table className="w-full border-collapse text-left">
            <thead>
              <tr>
                <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">Variable</th>
                <th className="border-b border-navy/20 pb-2 pr-4 text-[11px] font-normal text-slate-500">In this investigation</th>
                <th className="border-b border-navy/20 pb-2 text-[11px] font-normal text-slate-500">Baseline</th>
              </tr>
            </thead>
            <tbody>
              {report.params.map((param) => (
                <tr key={param.key}>
                  <td className="border-b border-mist py-2 pr-4 text-[12px] text-ink">{param.label}</td>
                  <td className="border-b border-mist py-2 pr-4 font-mono text-[12px] text-navy">
                    {format(param.value, param.format)}
                    {param.changed ? <span className="ml-2 text-[10px] uppercase tracking-[0.08em] text-[#8a6420]">changed</span> : null}
                  </td>
                  <td className="border-b border-mist py-2 font-mono text-[12px] text-slate-500">
                    {format(param.baseline, param.format)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        <Section
          title="Consequence map"
          note="The map exactly as it was saved, including any branches that were collapsed. The interactive version is in the Consequence Lab."
        >
          <GraphPanel
            run={report.run}
            view={record.graphState ?? DEFAULT_VIEW}
            onViewChange={() => {}}
            selectedId={record.selectedNodeId ?? 'decision'}
            onSelect={() => {}}
            height={520}
            hideToolbar
            hideInspector
          />
        </Section>

        <Section
          title="Results and calculations"
          note="Each figure is arithmetic on the parameters above, with the substitution used shown beneath it."
        >
          {[...new Set(report.metrics.map((metric) => metric.group))].map((group) => (
            <div key={group} className="mt-4">
              <p className="font-mono text-[10px] uppercase tracking-[0.12em] text-slate-500">{group}</p>
              <table className="mt-2 w-full border-collapse text-left">
                <tbody>
                  {report.metrics
                    .filter((metric) => metric.group === group)
                    .map((metric) => (
                      <tr key={metric.key}>
                        <td className="w-[38%] border-b border-mist py-2 pr-4 align-top text-[12px] text-ink">
                          {metric.label}
                        </td>
                        <td className="border-b border-mist py-2 align-top">
                          <p className="tabular font-mono text-[12px] text-navy">
                            {format(metric.value, metric.format)}
                            <span className="ml-2 text-slate-400">baseline {format(metric.baseline, metric.format)}</span>
                          </p>
                          {metric.substitution ? (
                            <p className="mt-1 break-words font-mono text-[10.5px] leading-relaxed text-slate-500">
                              {metric.substitution}
                            </p>
                          ) : null}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ))}
        </Section>

        <Section title="Alternative scenarios kept with this investigation">
          <table className="w-full border-collapse text-left">
            <tbody>
              {report.alternatives.map((entry) => (
                <tr key={entry.key}>
                  <td className="w-[38%] border-b border-mist py-2.5 pr-4 align-top">
                    <span className="block font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">
                      {entry.scenario.shortTitle}
                    </span>
                    <span className="text-[12.5px] text-navy">{entry.alternative.short}</span>
                  </td>
                  <td className="border-b border-mist py-2.5 align-top text-[12px] leading-relaxed text-slate-600">
                    {entry.alternative.policySummary}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Section>

        <Section
          title="Stakeholder analysis"
          note="Groups are described by how modelled effects could reach them. No opinions are attributed to them."
        >
          {report.stakeholders.map((stakeholder) => (
            <div key={stakeholder.id} className="print-break mt-4 border-t border-mist pt-3">
              <p className="font-heading text-[16px] text-navy">{stakeholder.label}</p>
              <p className="mt-1 text-[12px] text-slate-600">{stakeholder.who}</p>
              <div className="mt-2 grid gap-x-8 gap-y-2 sm:grid-cols-2">
                <p className="text-[12px] leading-relaxed text-slate-600">
                  <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-teal">Benefits · </span>
                  {stakeholder.benefits.join('; ')}
                </p>
                <p className="text-[12px] leading-relaxed text-slate-600">
                  <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-[#8a6420]">Costs · </span>
                  {stakeholder.costs.join('; ')}
                </p>
                <p className="text-[12px] leading-relaxed text-slate-600">
                  <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-slate-500">Uncertainties · </span>
                  {stakeholder.uncertainties.join('; ')}
                </p>
                <p className="text-[12px] leading-relaxed text-slate-600">
                  <span className="font-mono text-[10px] uppercase tracking-[0.1em] text-[#8a6420]">Conflicts · </span>
                  {stakeholder.conflicts.join('; ')}
                </p>
              </div>
            </div>
          ))}
        </Section>

        <Section title="Assumptions">
          <ul className="space-y-2.5">
            {report.scenario.assumptions.map((assumption) => (
              <li key={assumption.id} className="border-t border-mist pt-2">
                <p className="text-[12px] text-navy">{assumption.label}</p>
                <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-600">{assumption.text}</p>
              </li>
            ))}
          </ul>
        </Section>

        <Section
          title="Evidence"
          note="Every consequence node carries one of four evidence labels. No citation appears in this application unless a verified source is attached."
        >
          <div className="flex flex-wrap gap-2">
            <Chip>Calculated from inputs: {report.evidence.calculated}</Chip>
            <Chip>Illustrative assumptions: {report.evidence.assumption}</Chip>
            <Chip>Unverified hypotheses: {report.evidence.hypothesis}</Chip>
            <Chip>Research-supported with attached source: {report.evidence.research}</Chip>
          </div>
          <div className="mt-4 space-y-2">
            {report.nodes
              .filter((node) => node.type !== 'decision')
              .map((node) => (
                <div key={node.id} className="border-t border-mist pt-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">
                      {LEVELS[Math.min(node.level, 3)].short} · {node.category}
                    </span>
                    <EvidenceBadge level={node.evidence} />
                    <span className="font-mono text-[9.5px] uppercase tracking-[0.1em] text-slate-500">
                      {DIRECTION_LABEL[node.direction]}
                    </span>
                  </div>
                  <p className="mt-1 text-[12px] text-ink">{node.title}</p>
                  {node.value ? <p className="mt-0.5 font-mono text-[10.5px] text-slate-500">{node.value}</p> : null}
                  {node.formula ? (
                    <p className="mt-0.5 font-mono text-[10.5px] leading-relaxed text-slate-500">{node.formula}</p>
                  ) : null}
                </div>
              ))}
          </div>
        </Section>

        <Section title="Unanswered questions">
          <ul className="space-y-2">
            {report.questions.map((question, index) => (
              <li key={index} className="border-t border-mist pt-2 text-[12px] leading-relaxed text-slate-600">
                {question}
              </li>
            ))}
          </ul>
        </Section>

        {record.notes?.length ? (
          <Section title="Your notes">
            <ul className="space-y-2">
              {record.notes.map((note, index) => (
                <li key={index} className="border-t border-mist pt-2 text-[12px] leading-relaxed text-slate-600">
                  {note}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {report.nodeNotes.length ? (
          <Section title="Notes and evidence attached to consequences">
            <ul className="space-y-2">
              {report.nodeNotes.map((entry) => {
                const node = report.run.graph.byId.get(entry.nodeId);
                return (
                  <li key={entry.nodeId} className="border-t border-mist pt-2">
                    <p className="text-[12px] text-navy">{node?.title ?? entry.nodeId}</p>
                    <p className="mt-0.5 text-[11.5px] leading-relaxed text-slate-600">{entry.note?.text}</p>
                    {entry.note?.links?.[0]?.url ? (
                      <p className="mt-0.5 font-mono text-[10.5px] text-teal">{entry.note.links[0].url}</p>
                    ) : null}
                  </li>
                );
              })}
            </ul>
          </Section>
        ) : null}
      </article>
    </div>
  );
}